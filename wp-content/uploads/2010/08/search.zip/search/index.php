<?php
/*
 This file is part of Silex: RIA developement tool - see http://silex-ria.org/

Silex is (c) 2007-2012 Silex Labs and is released under the GPL License:

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License (GPL) as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/
// include './rootdir.php'; we do not call rootdir.php for the moment as it's already within the filepath. Also this includes seems to break the administration part of the plugin. If we notice some cases where ROOTPATH isn't known when we call index.php, we will have to rethink this part.
require_once ROOTPATH.'cgi/includes/plugin_base.php';

class search_management extends plugin_base
{

	/**
	* Returns the html code corresponding to the administration page of the plugin.
	* In that case, we call the create_website_index.php script of the search plugin passing the site name in parameter
	* @return string
	*/
	public function getAdminPage($siteName)
	{
		$result = "
			<html>
				<body>
				
					<img src='plugins/".$this->pluginName."/plugin.png' alt='".$this->pluginName."' /><br/><br/>
					
					<div id=\"indexation\">
						
						<input type=\"button\" value=\"index\" onclick=\"javascript:$.get( 'plugins/".$this->pluginName."/create_website_index.php', {id_site: '".$siteName."' }, function( data ) { $('#indexation').html(data); } );\"> 
					
					</div>
					
				</body>
			</html>
			" ;
			
        return $result;
	}
	
}

?>
