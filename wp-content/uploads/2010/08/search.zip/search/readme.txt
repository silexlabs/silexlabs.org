notes for search_plugin, by Thomas F�tiveau (thomas.fetiveau.tech@gmail.com) 06-30-2010
--------------------------------------------------------------------------------------------
This plugin allows you to index the contents of a given site though the new Silex manager. It then makes possible performing search queries in the indexed site's contents.


USE INSTRUCTIONS

To index a site, open the silex manager and go to manage&gt;[your_site]&gt;plugins. Activate the search plugin for your site and then select it in the installed plugins list. The administration page of the plugin will show up and should propose to click on a "index" button. Once the site indexed, a message confirming that the site has been indexed should be printed.

Once a site is indexed, this plugin also allows you to perform search queries in the site's contents. The script you have to call for such queries is the feed.php script inside the plugin directory (its use doesn't require that you activate the search plugin for a given site). The results of the queries are return in the rss format. To read the instructions for using this feed.php script, simply open a web browser and give it the script's address without passing any GET parameters (for example : http://[my_silex_server_address]/plugins/search/feed.php). The feed.php help page should then show up.


INSTALLATION INSTRUCTIONS

To install it drop the search folder in the silex "plugins" folder, 

To activate it for a specific site, add it to the PLUGINS_LIST parameter of your site in contents/[your_site]/conf.txt. Each plugin listed in this parameter is separated by the character @

ex : PLUGINS_LIST=wysiwyg@search@snapshot&

note: there is no use to activate this plugin at the Silex server level. You may use it only at Silex site level.

It is made up of :
- index.php : contains the management class of the plugin
- create_website_index.php : the script performing the indexation of a given site
- feed.php : the script that allows to consult indexed contents
- silex_search.php : class used by the indexation
- The Zend libraries used by the indexation.

