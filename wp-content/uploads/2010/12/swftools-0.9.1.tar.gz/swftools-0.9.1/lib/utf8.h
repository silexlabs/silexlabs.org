#ifndef __utf8_h__
#define __utf8_h__
void writeUTF8(unsigned int charnum, char*dest);
char* getUTF8(unsigned int charnum);
#endif
