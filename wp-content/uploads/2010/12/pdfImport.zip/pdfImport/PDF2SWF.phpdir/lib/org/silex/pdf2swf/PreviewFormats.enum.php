<?php

class org_silex_pdf2swf_PreviewFormats extends Enum {
	public static $jpg;
	public static $png;
	public static $__constructors = array(1 => 'jpg', 0 => 'png');
	}
org_silex_pdf2swf_PreviewFormats::$jpg = new org_silex_pdf2swf_PreviewFormats("jpg", 1);
org_silex_pdf2swf_PreviewFormats::$png = new org_silex_pdf2swf_PreviewFormats("png", 0);
