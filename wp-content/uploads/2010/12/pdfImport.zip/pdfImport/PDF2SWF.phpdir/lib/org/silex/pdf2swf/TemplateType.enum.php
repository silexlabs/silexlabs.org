<?php

class org_silex_pdf2swf_TemplateType extends Enum {
	public static $FirstPage;
	public static $LastPage;
	public static $NormalPage;
	public static $__constructors = array(0 => 'FirstPage', 2 => 'LastPage', 1 => 'NormalPage');
	}
org_silex_pdf2swf_TemplateType::$FirstPage = new org_silex_pdf2swf_TemplateType("FirstPage", 0);
org_silex_pdf2swf_TemplateType::$LastPage = new org_silex_pdf2swf_TemplateType("LastPage", 2);
org_silex_pdf2swf_TemplateType::$NormalPage = new org_silex_pdf2swf_TemplateType("NormalPage", 1);
