<?php

class PDF2SWF {
	public function __construct() { ;
		;
		;
	}
	static function main() {
		$m = new PDF2SWF();
		chdir("../../..");
		org_silex_serverApi_helpers_Env::setIncludePath((org_silex_serverApi_helpers_Env::getIncludePath() . org_silex_serverApi_helpers_Env::getPathSeparator()) . "cgi/library");
		$pluginsConfig = _hx_deref(new org_silex_serverApi_ConfigEditor())->readConfigFile(_hx_deref(new org_silex_serverApi_ServerConfig())->getSilexServerIni()->get("SILEX_PLUGINS_CONF"), "phparray");
		$opt = null;
		$opt = _hx_anonymous(array("leftPageXOffset" => 0.0, "leftPageYOffset" => 0.0, "pageWidth" => 512.0, "pageHeight" => 768.0, "rightPageXOffset" => 512.0, "rightPageYOffset" => 0.0, "namePrefix" => "catalogue", "swfDirectoryName" => "./contents/myPubHor/swfs", "publicationName" => "myPubHor", "previewFormat" => org_silex_pdf2swf_PreviewFormats::$png, "hasCover" => false, "hasDoublePages" => false, "pageName" => "page", "pathToSWFTools" => ""));
		if(php_Web::getParams()->get("leftPageXOffset") !== "") {
			$opt->leftPageXOffset = Std::parseFloat(php_Web::getParams()->get("leftPageXOffset"));
			;
		}
		if(php_Web::getParams()->get("leftPageYOffset") !== "") {
			$opt->leftPageYOffset = Std::parseFloat(php_Web::getParams()->get("leftPageYOffset"));
			;
		}
		if(php_Web::getParams()->get("rightPageXOffset") !== "") {
			$opt->rightPageXOffset = Std::parseFloat(php_Web::getParams()->get("rightPageXOffset"));
			;
		}
		if(php_Web::getParams()->get("rightPageYOffset") !== "") {
			$opt->rightPageYOffset = Std::parseFloat(php_Web::getParams()->get("rightPageYOffset"));
			;
		}
		if(php_Web::getParams()->get("pageWidth") !== "") {
			$opt->pageWidth = Std::parseFloat(php_Web::getParams()->get("pageWidth"));
			;
		}
		if(php_Web::getParams()->get("pageHeight") !== "") {
			$opt->pageHeight = Std::parseFloat(php_Web::getParams()->get("pageHeight"));
			;
		}
		if(php_Web::getParams()->get("namePrefix") !== "") {
			$opt->namePrefix = php_Web::getParams()->get("namePrefix");
			;
		}
		if(php_Web::getParams()->get("swfDirectoryName") !== "") {
			$opt->swfDirectoryName = php_Web::getParams()->get("swfDirectoryName");
			;
		}
		if(php_Web::getParams()->get("publicationName") !== "") {
			$opt->publicationName = php_Web::getParams()->get("publicationName");
			;
		}
		if(php_Web::getParams()->get("hasCover") !== "") {
			$opt->hasCover = PDF2SWF_0($m, $opt, $pluginsConfig);
			;
		}
		if(php_Web::getParams()->get("hasDoublePages") !== "") {
			$opt->hasDoublePages = PDF2SWF_1($m, $opt, $pluginsConfig);
			;
		}
		if(php_Web::getParams()->get("pageName") !== "") {
			$opt->pageName = php_Web::getParams()->get("pageName");
			;
		}
		if($pluginsConfig->get("pathToSWFTools") !== null) {
			$opt->pathToSWFTools = $pluginsConfig->get("pathToSWFTools");
			;
		}
		$fst = new org_silex_serverApi_FileSystemTools();
		switch(php_Web::getParams()->get("action")) {
		case "convertPage":{
			if(php_Web::getParams()->get("page") === "" || php_Web::getParams()->get("page") === null) {
				php_Lib::println("Error");
				;
			}
			$toReturn = org_silex_pdf2swf_PDF2SWFConverter::generatePageSWF(php_Web::getParams()->get("pdfFile"), $opt, Std::parseInt(php_Web::getParams()->get("page")));
			$msg = null;
			$�t = ($toReturn);
			switch($�t->index) {
			case 2:
			{
				php_Lib::hprint("PageDoesNotExist");
				;
			}break;
			case 0:
			$msg1 = $�t->params[0];
			{
				php_Lib::hprint("Done " . $msg1);
				;
			}break;
			case 1:
			$msg1 = $�t->params[0];
			{
				php_Lib::hprint("Error " . $msg1);
				;
			}break;
			}
			unset($toReturn,$msg);
		}break;
		case "generatePublicationStructure":{
			if(php_Web::getParams()->get("startPage") === "" || php_Web::getParams()->get("startPage") === null) {
				php_Lib::println("Error");
				;
			}
			if(php_Web::getParams()->get("silexPage") === "" || php_Web::getParams()->get("silexPage") === null) {
				php_Lib::println("Error");
				;
			}
			$toReturn = org_silex_pdf2swf_PDF2SWFConverter::generatePublication($opt, Std::parseInt(php_Web::getParams()->get("pageNumber")), Std::parseInt(php_Web::getParams()->get("startPage")), Std::parseInt(php_Web::getParams()->get("silexPage")), php_Web::getParams()->get("layerName"), php_Web::getParams()->get("importFormat"));
			$�t = ($toReturn);
			switch($�t->index) {
			case 0:
			$msg = $�t->params[0];
			{
				php_Lib::hprint($msg);
				;
			}break;
			case 1:
			$msg = $�t->params[0];
			{
				php_Lib::hprint("Error " . $msg);
				;
			}break;
			case 2:
			{
				null;
				;
			}break;
			}
			unset($toReturn);
		}break;
		}
		unset($pluginsConfig,$opt,$m,$fst);
	}
	static function sanitizeOptions($opt) {
		if($opt->hasDoublePages) {
			$opt->hasCover = false;
			;
		}
		return $opt;
		;
	}
	function __toString() { return 'PDF2SWF'; }
}
;
function PDF2SWF_0(&$m, &$opt, &$pluginsConfig) {
if(php_Web::getParams()->get("hasCover") === "true") {
	return true;
	;
}
else {
	return false;
	;
}
}
function PDF2SWF_1(&$m, &$opt, &$pluginsConfig) {
if(php_Web::getParams()->get("hasDoublePages") === "true") {
	return true;
	;
}
else {
	return false;
	;
}
}