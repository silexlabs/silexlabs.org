<?php

class PDFGUIWebService {
	public function __construct(){}
	static function main() {
		chdir("../../..");
		org_silex_serverApi_helpers_Env::setIncludePath((org_silex_serverApi_helpers_Env::getIncludePath() . org_silex_serverApi_helpers_Env::getPathSeparator()) . "cgi/library");
		$ctx = new haxe_remoting_Context();
		$ctx->addObject("Service", _hx_qtype("pdfGUIWebService.Server"), null);
		if(haxe_remoting_HttpConnection::handleRequest($ctx)) {
			return;
			;
		}
		PDFGUIWebService::printHelpMessage();
		unset($ctx);
	}
	static function printHelpMessage() {
		php_Lib::hprint("This is a haXe remoting server.");
		php_Lib::hprint("You cannot access it directly.");
		php_Lib::hprint("includePath:" . org_silex_serverApi_helpers_Env::getIncludePath());
		;
	}
	function __toString() { return 'PDFGUIWebService'; }
}
