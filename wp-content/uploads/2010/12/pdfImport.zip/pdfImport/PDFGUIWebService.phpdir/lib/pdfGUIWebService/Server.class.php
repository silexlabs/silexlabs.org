<?php

class pdfGUIWebService_Server {
	public function __construct(){}
	static function sayHello() {
		return "Hello Client";
		;
	}
	static function listPublications() {
		$res = new _hx_array(array());
		$fs = new org_silex_serverApi_FileSystemTools();
		{
			$_g = 0; $_g1 = $fs->listFolderContent("contents", true, null, null, null);
			while($_g < $_g1->length) {
				$f = $_g1[$_g];
				++$_g;
				if($f->itemContent !== null) {
					$res->push($f->itemName);
					;
				}
				unset($f);
			}
			unset($_g1,$_g);
		}
		return $res;
		unset($res,$fs);
	}
	static function listThemes() {
		$res = new _hx_array(array());
		$fs = new org_silex_serverApi_FileSystemTools();
		{
			$_g = 0; $_g1 = $fs->listFolderContent("contents_themes", true, null, null, null);
			while($_g < $_g1->length) {
				$f = $_g1[$_g];
				++$_g;
				if($f->itemContent !== null) {
					$res->push($f->itemName);
					;
				}
				unset($f);
			}
			unset($_g1,$_g);
		}
		return $res;
		unset($res,$fs);
	}
	static function listPdfFiles() {
		$res = new _hx_array(array());
		$fs = new org_silex_serverApi_FileSystemTools();
		{
			$_g = 0; $_g1 = pdfGUIWebService_Server::parseFileListResult($fs->listFolderContent("media", true, new _hx_array(array("pdf")), null, null), "media");
			while($_g < $_g1->length) {
				$f = $_g1[$_g];
				++$_g;
				if(strtolower($f->item->ext) === "pdf") {
					$res->push($f->path);
					;
				}
				unset($f);
			}
			unset($_g1,$_g);
		}
		return $res;
		unset($res,$fs);
	}
	static function parseFileListResult($result, $basePath) {
		$res = new _hx_array(array());
		{
			$_g = 0;
			while($_g < $result->length) {
				$f = $result[$_g];
				++$_g;
				if($f->itemContent === null) {
					$res->push(_hx_anonymous(array("path" => ($basePath . "/") . $f->itemName, "item" => $f)));
					;
				}
				else {
					$res = $res->concat(pdfGUIWebService_Server::parseFileListResult($f->itemContent, ($basePath . "/") . $f->itemName));
					;
				}
				unset($f);
			}
			unset($_g);
		}
		return $res;
		unset($res);
	}
	static function createPublication($id_site, $width, $height) {
		$se = new org_silex_serverApi_SiteEditor();
		if($se->createWebsite($id_site)) {
			$siteConf = $se->getWebsiteConfig($id_site, null);
			$siteConf->set("layoutStageWidth", Std::string($width));
			$siteConf->set("layoutStageHeight", Std::string($height));
			$se->writeWebsiteConfig($siteConf, $id_site);
			unset($siteConf);
		}
		else {
			throw new HException("Couldn't create website");
			;
		}
		unset($se);
	}
	static function duplicateTheme($themeName, $newName) {
		$se = new org_silex_serverApi_SiteEditor();
		if($se->duplicateWebsite($themeName, $newName) === "") {
			return true;
			;
		}
		else {
			throw new HException("Couldn't duplicate theme");
			;
		}
		unset($se);
	}
	static function basicInfoOnWebsite($id_site) {
		$ps = null;
		try {
			$ps = org_silex_publication_PublicationStructureParser::xml2PS(Xml::parse(php_io_File::getContent(("contents/" . $id_site) . "/structure.xml")));
			;
		}catch(Exception $�e) {
		$_ex_ = ($�e instanceof HException) ? $�e->e : $�e;
		;
		{ $e = $_ex_;
		{
			return null;
			;
		}}}
		return _hx_anonymous(array("hasCover" => $ps->hasCover, "hasDoublePages" => $ps->hasDoublePages));
		unset($ps,$e);
	}
	static function getPathToSWFTools() {
		try {
			$conf = new org_silex_serverApi_ConfigEditor();
			$res = $conf->readConfigFile("conf/plugins_server.php", "phparray");
			return $res->get("pathToSWFTools");
			unset($res,$conf);
		}catch(Exception $�e) {
		$_ex_ = ($�e instanceof HException) ? $�e->e : $�e;
		;
		{ $e = $_ex_;
		{
			return "";
			;
		}}}
		unset($e);
	}
	function __toString() { return 'pdfGUIWebService.Server'; }
}
