<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"> 
<html style="overflow:auto; height:100%;margin:0px;padding:0px;"> 
<head> 
	<title>PDF Upload</title> 
	<!--<link rel="stylesheet" type="text/css"  href="interface.css" />-->
	<!--<script language="javascript" src="PDFGUI.js" />-->
	<script language="javascript">
		function returnValue(fileName){
			var opt = document.createElement('option');
			opt.text = opt.value = fileName;
			document.getElementById('pathToPDF').add(opt,null);
			document.getElementById('pathToPDF').selectedIndex = document.getElementById('pathToPDF').options.length-1;
		}
	</script>
</head>
<body>
<?php
	/*include('./upload_include.php');
	$includeElement = new UploadInclude();
	$includeElement->echoAll();
	//echo ini_get('post_max_size');
	$includeElement->maxFilesize();*/

	$result1 = file_get_contents("../../plugins/pdfImport/interface.html");
	$result2 = str_replace( '%upLoadString%' , '<td><label for="pathToPDF">Upload a PDF</label></td>
				<td> <iframe name = "upload" SRC = "upload_form.php" height = "40" width = "350" FRAMEBORDER = "no"> </iframe></td>' , $result1 );
	$result3 = str_replace( '%refreshString%' , '' , $result2 );
	$finalResult = str_replace( '%pluginURL%' , '' , $result3 );
	echo $finalResult;
?>
	<script type="text/javascript" src="PDFGUI.js"></script>
</body>
</html> 