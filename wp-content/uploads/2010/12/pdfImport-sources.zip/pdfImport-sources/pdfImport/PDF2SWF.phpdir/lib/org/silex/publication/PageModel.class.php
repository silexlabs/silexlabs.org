<?php

class org_silex_publication_PageModel {
	public function __construct() {
		if( !php_Boot::$skip_constructor ) {
		$this->name = "";
		$this->title = "";
		$this->description = "";
		$this->deeplink = "";
		$this->keywords = new HList();
		$this->tags = new HList();
		$this->pageLeftNumber = 0;
		$this->pageRightNumber = 0;
		$this->enabled = false;
		$this->index = 0;
		;
	}}
	public $name;
	public $title;
	public $description;
	public $deeplink;
	public $keywords;
	public $tags;
	public $pageLeftNumber;
	public $pageRightNumber;
	public $enabled;
	public $index;
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->�dynamics[$m]) && is_callable($this->�dynamics[$m]))
			return call_user_func_array($this->�dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call �'.$m.'�');
	}
	function __toString() { return 'org.silex.publication.PageModel'; }
}
