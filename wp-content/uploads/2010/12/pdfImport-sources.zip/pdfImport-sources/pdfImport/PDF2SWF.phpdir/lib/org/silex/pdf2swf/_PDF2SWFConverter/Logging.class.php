<?php

class org_silex_pdf2swf__PDF2SWFConverter_Logging {
	public function __construct(){}
	static function log($text) {
		php_io_File::append("log-pdf.txt", false)->writeString((("\x0A" . Date::now()->toString()) . ": ") . $text);
		;
	}
	function __toString() { return 'org.silex.pdf2swf._PDF2SWFConverter.Logging'; }
}
