<?php

class org_silex_pdf2swf_ReturnCode extends Enum {
	public static function Done($msg) { return new org_silex_pdf2swf_ReturnCode("Done", 0, array($msg)); }
	public static function Error($msg) { return new org_silex_pdf2swf_ReturnCode("Error", 1, array($msg)); }
	public static $PageDoesNotExist;
	public static $__constructors = array(0 => 'Done', 1 => 'Error', 2 => 'PageDoesNotExist');
	}
org_silex_pdf2swf_ReturnCode::$PageDoesNotExist = new org_silex_pdf2swf_ReturnCode("PageDoesNotExist", 2);
