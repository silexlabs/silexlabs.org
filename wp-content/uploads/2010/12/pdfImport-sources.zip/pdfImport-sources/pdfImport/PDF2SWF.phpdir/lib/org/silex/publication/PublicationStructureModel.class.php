<?php

class org_silex_publication_PublicationStructureModel {
	public function __construct() {
		if( !php_Boot::$skip_constructor ) {
		$this->pages = new _hx_array(array());
		$this->setHasCover(true);
		$this->setHasDoublePages(true);
		;
	}}
	public $pages;
	public $hasCover;
	public $hasDoublePages;
	public function setHasCover($value) {
		$this->hasCover = $value;
		$this->recalculatePagesNumbers();
		return $this->hasCover;
		;
	}
	public function setHasDoublePages($value) {
		$this->hasDoublePages = $value;
		$this->recalculatePagesNumbers();
		return $this->hasDoublePages;
		;
	}
	public function recalculatePagesNumbers() {
		if(!$this->hasDoublePages) {
			$counter = 0;
			{
				$_g = 0; $_g1 = $this->pages;
				while($_g < $_g1->length) {
					$p = $_g1[$_g];
					++$_g;
					$counter++;
					$p->pageLeftNumber = $counter;
					$p->pageRightNumber = $counter;
					unset($p);
				}
				unset($_g1,$_g);
			}
			unset($counter);
		}
		else {
			$counter = 0;
			if($this->hasCover) {
				$counter = -1;
				;
			}
			{
				$_g = 0; $_g1 = $this->pages;
				while($_g < $_g1->length) {
					$p = $_g1[$_g];
					++$_g;
					$p->pageLeftNumber = ++$counter;
					$p->pageRightNumber = ++$counter;
					unset($p);
				}
				unset($_g1,$_g);
			}
			unset($counter);
		}
		;
	}
	public function getPageNumber($pageNumber) {
		{
			$_g = 0; $_g1 = $this->pages;
			while($_g < $_g1->length) {
				$p = $_g1[$_g];
				++$_g;
				if($p->pageLeftNumber === $pageNumber || $p->pageRightNumber === $pageNumber) {
					return $p;
					;
				}
				unset($p);
			}
			unset($_g1,$_g);
		}
		return null;
		;
	}
	public function save($basePath) {
		try {
			$path = $basePath . "/structure.xml";
			$fileOut = php_io_File::write($path, false);
			$fileOut->writeString(org_silex_publication_PublicationStructureParser::ps2XML($this)->toString());
			$fileOut->close();
			return true;
			unset($path,$fileOut);
		}catch(Exception $�e) {
		$_ex_ = ($�e instanceof HException) ? $�e->e : $�e;
		;
		{ $e = $_ex_;
		{
			return false;
			;
		}}}
		unset($e);
	}
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->�dynamics[$m]) && is_callable($this->�dynamics[$m]))
			return call_user_func_array($this->�dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call �'.$m.'�');
	}
	static function load($basePath) {
		$path = $basePath . "/structure.xml";
		$tmpPS = org_silex_publication_PublicationStructureParser::xml2PS(Xml::parse(php_io_File::getContent($path)));
		return $tmpPS;
		unset($tmpPS,$path);
	}
	function __toString() { return 'org.silex.publication.PublicationStructureModel'; }
}
