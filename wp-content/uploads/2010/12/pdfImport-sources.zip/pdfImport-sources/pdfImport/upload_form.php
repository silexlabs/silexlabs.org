<?php
	// This function transforms the php.ini notation for numbers (like '2M') to an integer (2*1024*1024 in this case)
	function letterToNumber($v){ 
		$l = substr($v, -1);
		$ret = substr($v, 0, -1);
		switch(strtoupper($l)){
		case 'P':
			$ret *= 1024;
		case 'T':
			$ret *= 1024;
		case 'G':
			$ret *= 1024;
		case 'M':
			$ret *= 1024;
		case 'K':
			$ret *= 1024;
			break;
		}
		return $ret;
	}
	// This function gives the upload maximum file size
	function maxFilesize() {
		$max_upload_size = min(letterToNumber(ini_get('post_max_size')), letterToNumber(ini_get('upload_max_filesize')));
		echo $max_upload_size;
	}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"> 
<html style="overflow:auto; height:100%;margin:0px;padding:0px;">
<head>
	<link rel="stylesheet" type="text/css" href="interface.css" />
</head>

<body>
	<form enctype="multipart/form-data" action="upload.php" method="POST">
		<!-- MAX_FILE_SIZE must precede the file input field -->
		<input type="hidden" name="MAX_FILE_SIZE" value=<?php echo maxFilesize(); ?> />
		<input name="userfile" type="file" />
		<input type="submit" value="Upload" class="orangeSubmitButton" />
	</form>
</body>