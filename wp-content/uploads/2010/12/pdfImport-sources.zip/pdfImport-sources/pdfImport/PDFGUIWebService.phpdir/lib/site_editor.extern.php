<?php

{
	require_once("cgi/includes/site_editor.php");
	;
}