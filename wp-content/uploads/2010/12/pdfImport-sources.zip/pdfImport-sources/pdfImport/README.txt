Installation
-------------

On Windows, get the binary file on the SWFTools official website: http://www.swftools.org/
Then, you simply have to install it.

On Linux, use your distribution's packet manager or any packet manager you may have.
Alternatively, you can use the source packages available on http://www.swftools.org


On MacOSX, things are a bit more complicated.
You have to get macports ( http://www.macports.org/ ). The simplest way is to use the DMG image.
Once you have installed it, open Terminal (it is under Applications > Tools). Then run the following command:

sudo port install swftools


On Linux, Windows and MacOSX you then simply have to copy the pdfImport folder into your silex's server's plugin directory.


Usage
-------------

To use the pdfImport plugin, you simply need to go to your server's manager click on Settings > Plugins > Activate a plugin and choose the PDFImport plugin.
After having done this once, you will need to go to Settings > Plugins > pdfImport.

Note that you may have to provide the "Path to SWFTools" field with the path where SWFTools has been installed. On MacOSX using the method provided before, it should be "/opt/local/bin/".
It is also possible to set it by opening silex_server/conf/plugins_server.php and adding the following line:

$conf['pathToSWFTools'] = '/opt/local/bin';

You can make sure of the path to be provided on MacOSX and Linux by opening a terminal and entering the following command:
which pdf2swf
Then, you will see an output, just remove the trailing "pdf2swf" from it.

