 Th�me ZenSushi

- Copiez collez le contenu des repertoires "contents/themes", "media", "loaders" et "layouts"
dans les repertoires correspondants de votre Silex server.

- t�l�chargez et installer le plugin excel disponible a cette addresse : http://exchange.silexlabs.org/?p=250


  *** *** *** *** *** ***


Comment utiliser le backoffice du th�me : 

-page accueil : ajoutez des images dans le dossier "media/zensushi/gallery/accueil". format conseill� 720x330px

-page pr�sentation : ajoutez les miniatures dans le dossier "media/zensushi/gallery/presentation/small". format conseill� 50x50px
		     ajoutez les images dans le dossier "media/zensushi/gallery/presentation/big". format conseill� 720x330px

Chaque miniature doit avoir le meme nom que l'image grand format.

Modifiez le fichier excel page pr�sentation :
	*La colonne A correspond � l'ordre dans la liste inutile de la modifier. 
	*La colonne B correspond au nom de vos images. 
	*La colonne C correspond au texte de description en rapport avec l'image.

Dans silex selectionnez le DataSelectorShow de la page pr�sentation et modifiez dans le champ source la plage de recherche.

-page carte : ajoutez les images dans le dossier "media/zensushi/gallery/menu".

Modifiez le fichier excel page carte :
	*La colonne A correspond a l'ordre dans la liste inutile de modifier. 
	*La colonne B correspond au nom de vos plats. 
	*La colonne C correspond a la description de vos plats. 
	*La colonne D correspond au prix.
	*La colonne E correspond a l'image du plat. 
Les colonnes A � E gerrent la liste de gauche. Les colonnes G � K gerent la liste de droite.

Dans silex selectionnez, sur la page carte1 le DataSelectorCarte (pour la liste de gauche) ou DataSelectorcarte2 (pour la liste de droite) et modifiez dans le champ source la plage de recherche.


-page menus : ajoutez les images dans le dossier "media/zensushi/gallery/menu".

Modifiez le fichier excel page menus :
	*La colonne A correspond a l'ordre dans la liste inutile de modifier. 
	*La colonne B correspond au nom de vos plats. 
	*La colonne C correspond a la description de vos plats. 
	*La colonne D correspond au prix. 
	*La colonne E correspond a l'image du plat. 
Les colonnes A � E gerrent la liste de gauche. les colonnes G � K gerent la liste de droite.

Dans silex selectionnez, sur la page carte2 le DataSelectorCarte (pour la liste de gauche) ou DataSelectorcarte2 (pour la liste de droite) et modifiez dans le champ source la plage de recherche.


-page promotions : ajoutez les images dans le dossier "media/zensushi/gallery/menu".

Modifiez le fichier excel page carte : 
	*La colonne A correspond a l'ordre dans la liste inutile de modifier. 
	*La colonne B correspond au nom de vos plats. 
	*La colonne C correspond a la description de vos plats. 
	*La colonne D correspond au prix. 
	*La colonne E correspond a l'image du plat. 
Les colonnes A � E gerrent la liste de gauche. les colonnes G � K gerent la lliste de droite.
			
Dans silex selectionnez, sur la page carte3 le DataSelectorCarte (pour la liste de gauche) ou DataSelectorcarte2 (pour la liste de droite) et modifiez dans le champ source la plage de recherche.

-page evenements : ajoutez les miniatures dans le dossier "media/zensushi/gallery/evenements/small". format conseill� 300x75px
		   ajoutez les images dans le dossier "media/zensushi/gallery/evenements/big". format conseill� 720x330px

Chaque miniature doit avoir le meme nom que l'image grand format.

Modifiez le fichier excel page �v�nements :
	*La colonne A correspond � l'ordre dans la liste inutile de modifier. 
	*La colonne B correspond au nom de vos images. 
	*La colonne C correspond au texte de description en rapport avec l'image.
			
Dans silex selectionnez le DataSelectorShow de la page evenements et modifiez dans le champ source la plage de recherche.



//------------------------------------------------------------------------------//



ZenSushi Theme


- Copy and paste the content of the "contents/themes", "media", "loaders"   and "layouts" folders
into the corresponding directory of your Silex server.

- Download and install excel plugin for silex aviable here : http://exchange.silexlabs.org/?p=250


*** *** *** *** *** ***


How to use theme's backoffice : 

-accueil page : 	add pictures into file "media/zensushi/gallery/accueil". recommended size 720x330px

-presentation page  : 	add thumbs into file  "media/zensushi/gallery/presentation/small". recommended size 50x50px
			add pictures into file "media/zensushi/gallery/presentation/big". recommended size 720x330px
			each thumb must have the same name than big picture
			modify the excel file on "pr�sentation" page. column A refers to the order in the list, no need to touch. Column 							B refers to the name of your images. Column C refers to description text.
			On silex select DataSelectorShow on pr�sentation page and modify the search on attribute "source".

-page carte : 		add thumbs into file "media/zensushi/gallery/menu".
			modify the excel file on carte page. column A refers to the order in the list, no need to touch. Column B refers to the name of your 					plates. Column C refers to your plates descriptions. Column D refers to price. Column E refers to the plate picture. column A 				to E are for the left list. column G to K are for the right list.
			On silex select DataSelectorCarte (for left list) or DataSelectorcarte2 (for right list)  on page carte1 and modify the search on 				attribute "source".


-page menus : 		add thumbs into file "media/zensushi/gallery/menu".
			modify the excel file on carte page. column A refers to the order in the list, no need to touch. Column B refers to the name of your 					plates. Column C refers to your plates descriptions. Column D refers to price. Column E refers to the plate picture. column A 				to E are for the left list. column G to K are for the right list.
			On silex select DataSelectorCarte (for left list) or DataSelectorcarte2 (for right list)  on page carte2 and modify the search on 				attribute "source".


-page promotions : 	add thumbs into file "media/zensushi/gallery/menu".
			modify the excel file on carte page. column A refers to the order in the list, no need to touch. Column B refers to the name of your 					plates. Column C refers to your plates descriptions. Column D refers to price. Column E refers to the plate picture. column A 				to E are for the left list. column G to K are for the right list.
			On silex select DataSelectorCarte (for left list) or DataSelectorcarte2 (for right list)  on page carte3 and modify the search on 				attribute "source".

-page evenements : 	add thumbs into file "media/zensushi/gallery/evenements/small". recommended size 300x75px
			add pictures into file  "media/zensushi/gallery/evenements/big". recommended size 720x330px
			each thumb must have the same name than big picture
			modify the excel file on "evenements" page. column A refers to the order in the list, no need to touch. Column 								B refers to the name of your images. Column C refers to description text.
			On silex select DataSelectorShow on evenments page and modify the search on attribute "source".



