
Association 2010 Theme

	- Copy and paste the content of the "contents" in the "contents_themes" folder of your Silex server
	- Copy and paste the content of "media" in the "media" folder of your Silex server
	- Copy and paste the content of "loader" in the "loader" folder of your Silex server


	- To access this theme from your Manager, click on "Create" and then, on "Create a site from a template". 

This theme can be used on the V1.6.0 beta 7 version. If you use an older version (from the v1.6), copy and paste the content of "contents" in the "contents" folder of your Silex server. 

