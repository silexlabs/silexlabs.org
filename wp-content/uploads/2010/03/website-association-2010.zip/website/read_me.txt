Th�me Association 2010


- Remplacez le "loader.swf" � la racine de silex_server

- Copiez collez le contenu des repertoires "contents" et "media"
dans les repertoires correspondants de votre Silex server.





Association 2010 Theme


- Replace the "loader.swf" file in the root of your Silex server.

- Copy and paste the content of the "contents" and "media" folders
into the corresponding directory of your Silex server.





Tema My Page plus


- Reemplazar el "loader.swf" en la ra�z del Silex server.

- Copiar y pegar el contenido de las carpetas "content" y "media"
en el directorio correspondiente del Silex server.
