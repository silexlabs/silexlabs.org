﻿<?php

set_include_path(get_include_path() . PATH_SEPARATOR . "../../");

if (isset($_GET["id_site"]))
{

	require_once 'rootdir.php';
	set_include_path(get_include_path() . PATH_SEPARATOR . "../../" . PATH_SEPARATOR . ROOTPATH.'cgi/library/');
	include_once ROOTPATH.'cgi/includes/server_config.php';
	include_once ROOTPATH.'cgi/includes/config_editor.php';
	require_once ROOTPATH.'cgi/includes/file_system_tools.php';
	require_once 'silex_search.php';

	$server_config = new server_config();
	$fst = new file_system_tools();


	$id_site=$_GET["id_site"];
	
		
	$relPath = $server_config->silex_server_ini["CONTENT_FOLDER"].$id_site;
	$fullPath = ROOTPATH . $relPath;
	// check rights
	if ($fst->checkRights($fst->sanitize($fullPath),file_system_tools::ADMIN_ROLE,file_system_tools::WRITE_ACTION))
	{
		//if ($this->logger) $this->logger->debug("createWebsiteIndex($id_site)");
		
		// open website conf file
		//$websiteConfig = $this->getWebsiteConfig($id_site);
		$config_editor = new config_editor();
		$confFilePath = $relPath."/".$server_config->silex_server_ini["WEBSITE_CONF_FILE"];
		$websiteConfig = $config_editor->readConfigFile($confFilePath, "flashvars");
		
		// build the entry point (start xml file)
		$firstSectionName = $websiteConfig["CONFIG_START_SECTION"];
		//if ($this->logger) $this->logger->debug("createWebsiteIndex - start with section: $firstSectionName"); 

		// **
		// create search object
		$silex_search_obj=new silex_search($server_config->sepCharForDeeplinks);
			

		// create indexes
		$silex_search_obj->createIndex($relPath."/",$firstSectionName);
		
		echo "Your site $id_site has been successfully indexed.";
	}
	else{
		//if ($this->logger) $this->logger->emerg("createWebsiteIndex no rights to create website index for $id_site");
		//	return 0;
		echo "You do not have the necessary rights to create website index for $id_site";
	}	
}

?>