Flip book layout

version: 1.0.0 beta1
author: lex at silex dot tv
date: 05/2010
online demo: 
download url: http://wp-manager.silex-ria.org/?p=648

Download
> flip.swf.zip - the layout
> flip-sources.zip - the sources and tests

Installation

Installation of the layout
- download and unzip flip.zip from http://wp-manager.silex-ria.org/?p=648
- paste "flip.swf" into Silex "layouts/" folder

Installation of the test site
- download and unzip "flip-sources.zip" from http://wp-manager.silex-ria.org/?p=648
- paste "bin/flip.swf" into Silex "layouts/" folder
- paste "contents/flip/" into Silex "contents/" folder

Use

Add the flip configuration data into your publication conf.txt
	flipWidth=910&
	flipHeight=620&
	flipPosX=50&
	flipPosY=200&
	flipAlign=TopRight&
	flipDuration=20&

In the publication, open a page which uses "layouts/flip.swf" as the layout. In this page, you can add transparent media in the corners with the following instructions. 

For the top left corner :
	onPress layout.startFlip
	onPress silex.config.flipAlign=TopLeft
	onPress RichTextListFlipPages.selectedIndex=-1

For the top right corner :
	onPress layout.startFlip
	onPress silex.config.flipAlign=TopRight
	onPress RichTextListFlipPages.selectedIndex=+1

For the bottom left corner :
	onPress layout.startFlip
	onPress silex.config.flipAlign=BottomLeft
	onPress RichTextListFlipPages.selectedIndex=-1

For the bottom right corner :
	onPress layout.startFlip
	onPress silex.config.flipAlign=BottomRight
	onPress RichTextListFlipPages.selectedIndex=+1

When you put an internal link which opens a page of the flip book, before opening the page, choose the corner which will automatically turned with these instructions
	onRelease silex.config.flipAlign=TopLeft
or
	onRelease silex.config.flipAlign=TopRight
or
	onRelease silex.config.flipAlign=BottomLeft
or
	onRelease silex.config.flipAlign=BottomRight


___________________________________________________________________________________________________


TO DO
- cas limites (horizontale, coté fixe de la page au centre)
- click inthe corner => next page
- son et ombres
- lisence dans le code
??- action sur l'interpreteur : setPage => compare avec la page précédente et détermine le paramètre back ou forward
?- evenement de fin de loading images dans le flip book => demarre auto flip apres (dans gabarit silex)

BUGS
- mask disappear when mouse is in y=0



onPress layout.startFlip
onPress silex.config.flipAlign=TopRight
onPress RichTextListFlipPages.selectedIndex=+1

onPress layout.startFlip
onPress silex.config.flipAlign=TopLeft
onPress RichTextListFlipPages.selectedIndex=-1


___________________________________________________________________________________________________

onLoad silex.config.flipDuration=100
onLoad silex.config.flipWidth=638
onLoad silex.config.flipHeight=418
onLoad silex.config.flipAlign=TopRight



onRelease silex.config.flipWidth=910
onRelease silex.config.flipHeight=620
onRelease silex.config.flipPosX=50
onRelease silex.config.flipPosY=200
onRelease silex.config.flipAlign=TopRight
onRelease silex.config.flipDuration=1
onRelease RichTextListFlipPages.selectedIndex=+1

onRelease silex.config.flipWidth=910
onRelease silex.config.flipHeight=620
onRelease silex.config.flipPosX=50
onRelease silex.config.flipPosY=200
onRelease silex.config.flipAlign=TopLeft
onRelease silex.config.flipDuration=1
onRelease RichTextListFlipPages.selectedIndex=-1

page1
page2
page3
page4

flipbook.page.template
flip.swf
<<data>>