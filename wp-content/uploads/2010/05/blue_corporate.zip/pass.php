<?php
$authentication['LOGINS']['a'] = 'a';
?>