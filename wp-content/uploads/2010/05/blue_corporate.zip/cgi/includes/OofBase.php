<?php 
/*
	this file is part of OOF
	OOF : Open Source Open Minded Flash Components

	OOF is (c) 2008 Alexandre Hoyau and Ariel Sommeria-Klein. It is released under the GPL License:

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License (GPL)
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/


require_once("../includes/Logger.php");

class OofBase{
    var $logger = null;
    var $sqlConnection = null;
    var $config = null;

    function OofBase($loggerName){
        $this->logger = new Logger($loggerName);
    }
    
    function connectToDb(){
        $this->config = parse_ini_file("../../conf/OofDb.ini", false);
        //$this->logger->debug("connecting : , dbhost: ".$this->config["dbHost"].", db_log : ".$this->config["dbLog"].", db_pwd : ".$this->config["dbPwd"].", db_name : ".$this->config["dbName"]);
        $this->sqlConnection = mysql_connect($this->config["dbHost"], $this->config["dbLog"], $this->config["dbPwd"]);
        if(!$this->sqlConnection){
            $mess = "result=error:" . mysql_error()."- request id:$request_id";
            throw new Exception($mess);
        }
        if(!mysql_select_db($this->config["dbName"], $this->sqlConnection)){
            $mess = "result=error:" . mysql_error()."- request id:$request_id";
            throw new Exception($mess);
        }
    
    }
    
    /**
    * oofSqlQuery
    * @param String query
     * @returns RecordSet
    * logs then executes sql query
    */
    
    function oofSqlQuery($query){
        $this->logger->info("oofSqlQuery : ".$query);
        if($this->dbConnection == null){
            $this->connectToDb();
        }

        $ret = mysql_query($query, $this->sqlConnection);
        if(!$ret){
            $errorMessage = "error executing query : ".$query."\nError code : ".mysql_errno($this->sqlConnection) . "\nError text : " . mysql_error($this->sqlConnection);
            throw new Exception($errorMessage);
        }
        
        return $ret;
    }    

    /**
    * parseArrayToString
    * @param Array in
     * @returns String. parses ["aze", "rty", "uio"] to "aze, rty, uio"
    */
    function parseArrayToString($in){
         if(($in == null)){
            return "*"; 
        }else{
            $size = sizeof($in);
            $ret = $in[0];
            
            for ($i = 1; $i < $size; $i++){ 
                $ret = $ret.", ".$in[$i];
            }      
            return $ret;            
        }
    
    }

    /**
    * parseStringToArray. splits, then trims
    * @param String in
     * @returns Array. parses  "aze, rty, uio" to ["aze", "rty", "uio"]
    */
    function parseStringToArray($in){
        $splitted = split(",", $in);
        $size = sizeof($splitted);
        
        for ($i = 0; $i < $size; $i++){ 
            $splitted[$i] = trim($splitted[$i]);
        }      
        return $splitted;            
    }
}
?>