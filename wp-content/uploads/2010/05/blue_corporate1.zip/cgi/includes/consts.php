<?php
	define("AUTH_ROLE_USER", "authRoleUser"); 

?>