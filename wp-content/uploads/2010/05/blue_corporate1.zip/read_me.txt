_______________________________________
_______________ENGLISH_________________
_______________________________________


***************************************

To use this publication you have to include :

 - The loader_blue_corporate.swf file on the root of the silex serveur and rename it loader.swf;
 - The media/blue_corporate folder in the media folder in your silex server ;
 - The contents/blue_corporate folder in the contents folder in your silex_server;
 - The files of the cgi/services folder in the cgi folder of your silex server ;
 - The files of the cgi/includes folder in the cgi folder of your silex server ;
 - The files of the conf folder in the conf folder of your silex server ;
 - The files of the layouts folder in the layouts folder of your silex server.




***************************************

To do some modifications :

 You have to put the different folders and files of the fla folder in the fla folder of your silex dev_kit.

/!\WARNING : To puplish swf with those fla,please respect correctly the arborescence of all the folders.

***************************************

You can see an exemple of this publication at the following address : http://silexprod.com/silex_blue_corporate

*********************************************************************
PUBLICATION 'S AUTHOR : Solvejg Bougeois => http://solveig.bougeois.free.fr

_______________________________________
_______________FRANCAIS________________
_______________________________________


****************************************

Pour utiliser cette publication, il faut mettre :

 - Le ficher loader_blue_corporate.swf � la racine du serveur silex et le renommer loader.swf;
 - Le dossier media/blue_corporation dans le dossier media du serveur silex ;
 - Le dossier contents/blue_corporate dans le dossier contents du serveur silex ;
 - Les fichiers du dossier cgi/services dans le dossier cgi du serveur silex ;
 - Les fichiers du dossier cgi/includes dans le dossier cgi du serveur silex ;
 - Les fichiers du dossier conf dans le dossier conf du serveur silex ;
 - Les fichiers du dossier layouts dans le dossier layouts du serveur silex.


****************************************

Pour apporter quelques modifications :

 Vous devez mettre les diff�rents dossiers et fichiers contenus dans le dossier fla dans le dossier fla du silex dev_kit.

/!\ATTENTION : pour pouvoir publier les swf � partir de ces fla, il faut imp�rativement que vous respectiez l'arborescence de tous les dossiers.

****************************************

Vous pouvez voir un exemple d'utilisation de cette publication � l'adresse suivante : http://silexprod.com/silex_blue_corporate

________________________________________
LICENCE:
This file is part has been produced by or for Silex Labs and is (c) 2010-2012 Silex Labs. All the files distributed with this one are licensed under a Creative Commons Attribution 3.0 License: http://creativecommons.org/licenses/by/3.0/

For the most accurate and up-to-date material, please visit http://silexlabs.com/



*********************************************************************
AUTEUR DE LA PUBLICATION : Solvejg Bougeois => http://solveig.bougeois.free.fr
