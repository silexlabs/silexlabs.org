<?php
/*
This file is part of Silex - see http://projects.silexlabs.org/?/silex

Silex is © 2010-2011 Silex Labs and is released under the GPL License:

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License (GPL) as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/
// include './rootdir.php'; we do not call rootdir.php for the moment as it's already within the filepath. Also this includes seems to break the administration part of the plugin. If we notice some cases where ROOTPATH isn't known when we call index.php, we will have to rethink this part.
require_once ROOTPATH.'cgi/includes/plugin_base.php';

class flipBook extends plugin_base
{
	
	function initDefaultParamTable()
	{
		parent::initDefaultParamTable();
		
		// get plugin language data
		$langManager = LangManager::getInstance();
		$localisedFileUrl = $langManager->getLangFile($this->pluginName);
		$localisedStrings = $langManager->getLangObject($this->pluginName, $localisedFileUrl);

		// snapshot parameters have placed here on purpose as the flipBook plugin takes the X, Y, width & parameters from it.
		$this->paramTable = array( 
			array(
				'name' => 'snapShotTool_imageWidth',
				'label' => $localisedStrings['SNAPSHOT_IMAGE_WIDTH_LABEL'],
				'description' => $localisedStrings['SNAPSHOT_IMAGE_WIDTH_DESCRIPTION'],
				'value' => '',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => '200'
			),
			array(
				'name' => 'snapShotTool_imageHeight',
				'label' => $localisedStrings['SNAPSHOT_IMAGE_HEIGHT_LABEL'],
				'description' => $localisedStrings['SNAPSHOT_IMAGE_HEIGHT_DESCRIPTION'],
				'value' => '',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => '200'
			),
			array(
				'name' => 'snapShotTool_imageX',
				'label' => $localisedStrings['SNAPSHOT_IMAGE_X_POSITION_LABEL'],
				'description' => $localisedStrings['SNAPSHOT_IMAGE_X_POSITION_DESCRIPTION'],
				'value' => '0',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => '200'
			),
			array(
				'name' => 'snapShotTool_imageY',
				'label' => $localisedStrings['SNAPSHOT_IMAGE_Y_POSITION_LABEL'],
				'description' => $localisedStrings['SNAPSHOT_IMAGE_Y_POSITION_DESCRIPTION'],
				'value' => '0',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => '200'
			),
			array(
				'name' => 'snapShotTool_layoutDepth',
				'label' => $localisedStrings['SNAPSHOT_LAYOUT_DEPTH_LABEL'],
				'description' => $localisedStrings['SNAPSHOT_LAYOUT_DEPTH_DESCRIPTION'],
				'value' => '0',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => '2'
			),
			array(
				'name' => 'snapShotTool_imageType',
				'label' => $localisedStrings['SNAPSHOT_IMAGE_TYPE_LABEL'],
				'description' => $localisedStrings['SNAPSHOT_IMAGE_TYPE_DESCRIPTION'],
				'value' => 'png',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => '5'
			),
			array(
				'name' => 'flipDuration',
				'label' => $localisedStrings['FLIP_DURATION_LABEL'],
				'description' => $localisedStrings['FLIP_DURATION_DESCRIPTION'],
				'value' => '4',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
				),
			array(
				'name' => 'flipAlign',
				'label' => $localisedStrings['FLIP_ALIGN_LABEL'],
				'description' => $localisedStrings['FLIP_ALIGN_DESCRIPTION'],
				'value' => 'TopRight',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
				),
			array(
				'name' => 'flipRichTextListName',
				'label' => $localisedStrings['FLIP_RICH_TEXT_LIST_NAME_LABEL'],
				'description' => $localisedStrings['FLIP_RICH_TEXT_LIST_NAME_DESCRIPTION'],
				'value' => 'ListStructure',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
				),
			array(
				'name' => 'flipListObjectsPageNameField',
				'label' => $localisedStrings['FLIP_LIST_OBJECT_PAGE_NAME_FIELD_LABEL'],
				'description' => $localisedStrings['FLIP_LIST_OBJECT_PAGE_NAME_FIELD_DESCRIPTION'],
				'value' => 'name',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
			),
			array(
				'name' => 'flipMovementSmoothingRatio',
				'label' => $localisedStrings['FLIP_MOVEMENT_SMOOTHING_RATIO_LABEL'],
				'description' => $localisedStrings['FLIP_MOVEMENT_SMOOTHING_RATIO_DESCRIPTION'],
				'value' => '3',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
			),
			array(
				'name' => 'pageTurnSoundUrl',
				'label' => $localisedStrings['FLIP_PAGE_TURN_SOUND_URL_LABEL'],
				'description' => $localisedStrings['FLIP_PAGE_TURN_SOUND_URL_DESCRIPTION'],
				'value' => 'media/flip/turn.mp3',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
			),
			array(
				'name' => 'pageDragSoundUrl',
				'label' => $localisedStrings['FLIP_PAGE_DRAG_SOUND_URL_LABEL'],
				'description' => $localisedStrings['FLIP_PAGE_DRAG_SOUND_URL_DESCRIPTION'],
				'value' => 'media/flip/drag.mp3',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
			),
			array(
				'name' => 'GRADIENT_OVER_FILLTYPE',
				'label' => $localisedStrings['GRADIENT_OVER_FILLTYPE_LABEL'],
				'description' => $localisedStrings['GRADIENT_OVER_DESCRIPTION'],
				'value' => 'linear',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
			),
			array(
				'name' => 'GRADIENT_OVER_COLORS',
				'label' => $localisedStrings['GRADIENT_OVER_COLORS_LABEL'],
				'description' => $localisedStrings['GRADIENT_OVER_DESCRIPTION'],
				'value' => '000000,FFFFFF,999999',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
			),
			array(
				'name' => 'GRADIENT_OVER_ALPHAS',
				'label' => $localisedStrings['GRADIENT_OVER_ALPHAS_LABEL'],
				'description' => $localisedStrings['GRADIENT_OVER_DESCRIPTION'],
				'value' => '0,50,0',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
			),
			array(
				'name' => 'GRADIENT_OVER_RATIOS',
				'label' => $localisedStrings['GRADIENT_OVER_RATIOS_LABEL'],
				'description' => $localisedStrings['GRADIENT_OVER_DESCRIPTION'],
				'value' => '0,200,255',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
			),
			array(
				'name' => 'GRADIENT_UNDERINSIDE_FILLTYPE',
				'label' => $localisedStrings['GRADIENT_UNDERINSIDE_FILLTYPE_LABEL'],
				'description' => $localisedStrings['GRADIENT_UNDERINSIDE_DESCRIPTION'],
				'value' => 'linear',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
			),
			array(
				'name' => 'GRADIENT_UNDERINSIDE_COLORS',
				'label' => $localisedStrings['GRADIENT_UNDERINSIDE_COLORS_LABEL'],
				'description' => $localisedStrings['GRADIENT_UNDERINSIDE_DESCRIPTION'],
				'value' => '000000,000000',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
			),
			array(
				'name' => 'GRADIENT_UNDERINSIDE_ALPHAS',
				'label' => $localisedStrings['GRADIENT_UNDERINSIDE_ALPHAS_LABEL'],
				'description' => $localisedStrings['GRADIENT_UNDERINSIDE_DESCRIPTION'],
				'value' => '0,80',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
			),
			array(
				'name' => 'GRADIENT_UNDERINSIDE_RATIOS',
				'label' => $localisedStrings['GRADIENT_UNDERINSIDE_RATIOS_LABEL'],
				'description' => $localisedStrings['GRADIENT_UNDERINSIDE_DESCRIPTION'],
				'value' => '0,255',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
			),
			array(
				'name' => 'GRADIENT_UNDEROUTSIDE_FILLTYPE',
				'label' => $localisedStrings['GRADIENT_UNDEROUTSIDE_FILLTYPE_LABEL'],
				'description' => $localisedStrings['GRADIENT_UNDEROUTSIDE_DESCRIPTION'],
				'value' => 'linear',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
			),
			array(
				'name' => 'GRADIENT_UNDEROUTSIDE_COLORS',
				'label' => $localisedStrings['GRADIENT_UNDEROUTSIDE_COLORS_LABEL'],
				'description' => $localisedStrings['GRADIENT_UNDEROUTSIDE_DESCRIPTION'],
				'value' => '000000,000000',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
			),
			array(
				'name' => 'GRADIENT_UNDEROUTSIDE_ALPHAS',
				'label' => $localisedStrings['GRADIENT_UNDEROUTSIDE_ALPHAS_LABEL'],
				'description' => $localisedStrings['GRADIENT_UNDEROUTSIDE_DESCRIPTION'],
				'value' => '80,0',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
			),
			array(
				'name' => 'GRADIENT_UNDEROUTSIDE_RATIOS',
				'label' => $localisedStrings['GRADIENT_UNDEROUTSIDE_RATIOS_LABEL'],
				'description' => $localisedStrings['GRADIENT_UNDEROUTSIDE_DESCRIPTION'],
				'value' => '0,255',
				'restrict' => '',
				'type' => 'string',
				'maxChars' => ''
			)
		);
	}
}

?>
