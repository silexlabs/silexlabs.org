Th�me Mon Portfolio


- Remplacez le "loader.swf" � la racine de silex_server

- Copiez collez le contenu des repertoires "contents", "media" et "layouts"
dans les repertoires correspondants de votre Silex server.

- Copiez collez le "ListUi.cmp.swf" dans le repertoire : media/components/oof/




My Portfolio Theme


- Replace the "loader.swf" file in the root of your Silex server.

- Copy and paste the content of the "contents", "media"  and "layouts" folders
into the corresponding directory of your Silex server.

- Copy and paste "ListUi.cmp.swf" file in the root : media/components/oof/



Tema Mi Portfolio


- Reemplazar el "loader.swf" en la ra�z del Silex server.

- Copiar y pegar el contenido de las carpetas "content", "media" y "layouts"
en el directorio correspondiente del Silex server.

- Copiar y pegar "ListUi.cmp.swf" en el directorio : media/components/oof/