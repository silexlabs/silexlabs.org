Th�me Corporate


	- Copiez collez le contenu des repertoires "contents", "media" et "layouts"
	dans les repertoires correspondants de votre Silex server.

	- Facultatif : Remplacez le "loader.swf" et l'ic�ne "silex.ico" � la racine de silex_server





Corporate Theme


	- Copy and paste the content of the "contents", "media" and "layouts" folders
	into the corresponding directory of your Silex server.

	- Optional : Replace the "loader.swf" and "silex.ico" files in the root of your Silex server.




Tema My Page plus


	- Copiar y pegar el contenido de las carpetas "content", "media" y "layouts"
	en el directorio correspondiente del Silex server.

	- Optativo: Reemplazar el "loader.swf" y "silex.ico" en la ra�z del Silex server.
