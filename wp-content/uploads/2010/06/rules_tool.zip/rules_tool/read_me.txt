OUTIL REGLE

- Copiez collez le "rulers_tool.swf"dans le repertoire "tools" du Silex server.
- Personnalisez votre r�gle avec le fichier fla.




RULERS TOOL

- Copy and paste the rulers_tool.swf" into the directory of your Silex server.
- Modify your ruler with the fla file.



HERRAMIENTA REGLA

- Copiar y pegar el "rulers_tool.swf" en el directorio del Silex server.
- Modificais vuestro regla con fla fichero.