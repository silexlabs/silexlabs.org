#!/bin/bash
/opt/mtasc/mtasc ../org/silex/core/Api.as -swf ../silex_server/silex.swf -main -header 800:600:20 -cp ../