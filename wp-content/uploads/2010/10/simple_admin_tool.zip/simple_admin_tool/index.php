<?php
/*
 This file is part of Silex: RIA developement tool - see http://silex-ria.org/

Silex is (c) 2007-2012 Silex Labs and is released under the GPL License:

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License (GPL) as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/
// include './rootdir.php'; we do not call rootdir.php for the moment as it's already within the filepath. Also this includes seems to break the administration part of the plugin. If we notice some cases where ROOTPATH isn't known when we call index.php, we will have to rethink this part.
require_once ROOTPATH.'cgi/includes/plugin_base.php';

class simple_admin_tool extends plugin_base
{
	
	public function initHooks($hookManager)
	{
		$hookManager->addHook('index-body-end', array($this, 'simple_admin_tool_index_body_end_hook'));
	}

	
	/**
	 * Silex hook for the script tag
	 */
	public function simple_admin_tool_index_body_end_hook()
	{
		?> 
		<script type="text/javascript">
			// <![CDATA[
			//alert("simple_admin_tool_index_body_end_hook");
			silexNS.HookManager.addHook("silexAdminApiReady",init_simple_admin_tool);
			
			function init_simple_admin_tool()
			{
				//alert("init_simple_admin_tool" + document.getElementById('silex').SetVariable);
				silexNS.SilexAdminApi.callApiFunction("viewMenuItems", "addItem", [$rootUrl+"plugins/simple_admin_tool/view_menu_item.swf"]);
				document.getElementById('silex').SetVariable('silex_exec_str','load_clip:plugins,plugins/simple_admin_tool/stage_element.swf');
		//		document.getElementById('silex').SetVariable('silex_exec_str','alert:<<plugins>>');
			}
			
			function simple_admin_tool_js_feed_back(){
				//alert("simple_admin_tool_js_feed_back" + document.getElementById('view_menu'));
				document.getElementById('view_menu').simple_admin_tool_view_menu_item_feed_back();
			}
			
			function simple_admin_tool_js_go(){
				//alert("simple_admin_tool_js_go");
				document.getElementById('silex').simple_admin_tool_stage_element_go();
			}
			
		   // ]]>
		</script>
		<?php
		return true;
	}
	
}

?>
