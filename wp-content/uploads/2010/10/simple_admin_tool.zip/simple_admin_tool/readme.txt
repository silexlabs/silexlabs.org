notes for simple_admin_tool, by Ariel Sommeria-klein 20/5/2010
----------------------------------------------------------------
This is a demonstration admin tool plugin. 
It loads a simple view menu item in the view menu, that shows "GO", and an invisible SWF in Silex. Once you click GO, it communicates with the invisible SWF in Silex and tells it to show itself. Then you can click "feedback" in the newly visible swf and it tells the view menu item to hide itself.


INSTALLATION INSTRUCTIONS

To install it, drop the simple_admin_tool folder in the silex /plugins folder, 

You can activate it for a specific site or for the entire Silex server (for all sites hosted by your Silex server) through the Silex manager. Otherwise, you can do the same manually :

 - To activate this plugin manually for specific site, add it to the PLUGINS_LIST parameter of your site in contents/[your_site]/conf.txt. Each plugin listed in this parameter is separated by the character @

   ex : PLUGINS_LIST=wysiwyg@search@simple_admin_tool&

 - To activate it manually at the Silex server level : edit the /conf/plugins_server.php file and add it to the $conf['PLUGINS_LIST'] parameter
 
   ex : $conf['PLUGINS_LIST'] = 'wysiwyg@snapshot@simple_admin_tool';


It is made up of :
- index.php : contains the php and js necessary to load the plugin. It waits for the hook SilexAdminApiReady to be called.  Then  it inserts a reference to view_menu_item.swf in the admin api's view menu items. Then it loads the stage_element in silex. Finally it has the two javascript functions used by the 2 swfs to communicate.
- view_menu_item.swf : the view menu item on which you can click. In AS3 . Sources in src/view_menu_item
- stage_element.swf : the element loaded into silex. In AS2. Sources in src/stage_element

