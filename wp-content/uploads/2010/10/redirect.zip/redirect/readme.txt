notes for redirect plugin
----------------------------------------------------------------
This is a redirection plugin for Silex. 

To install it drop the "redirect/" folder in the silex plugins folder, and then activate the plugin in your manager, for the whole Silex server or for a given publication.

The parameters :
- Address to redirect to
  > This is the address where you want to redirect the user.