<?php
/*
 This file is part of Silex: RIA developement tool - see http://silex-ria.org/

Silex is (c) 2007-2012 Silex Labs and is released under the GPL License:

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License (GPL) as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/
// include './rootdir.php'; we do not call rootdir.php for the moment as it's already within the filepath. Also this includes seems to break the administration part of the plugin. If we notice some cases where ROOTPATH isn't known when we call index.php, we will have to rethink this part.
require_once ROOTPATH.'cgi/includes/plugin_base.php';

class redirect extends plugin_base
{
	
	function initDefaultParamTable()
	{
		$this->paramTable = array( 
			array(
				"name" => "redirectUrl",
				"label" => "Address to redirect to",
				"description" => "This is the address where you want to redirect the user.",
				"value" => "",
				"restrict" => "",
				"type" => "string",
				"maxChars" => "255"
			)
		);
	}
	
	public function initHooks($hookManager)
	{
		$hookManager->addHook('index-body-end', array($this, 'redirect_index_body_end_hook'));
	}

	/**
	 * Silex hook for the script tag
	 */
	public function redirect_index_body_end_hook()
	{
		global $id_site;
		
		$i = 0;
		while( $i < count( $this->paramTable ) )
		{
			if($this->paramTable[$i]["name"] == "redirectUrl")
				$redirectUrl = $this->paramTable[$i]["value"];
/*			else if($this->paramTable[$i]["name"] == "siteID")
				$siteID = $this->paramTable[$i]["value"];*/
			$i++;
		}

		?>
			<script type="text/javascript">
				// prevent loading silex.swf
				onLoadBodyCallbackOccured= true;
				
				// redirect
				window.location = "<?php echo $redirectUrl; ?>";
			</script>
		<?php
	}
	
}

?>
