﻿<?php
/*
 This file is part of Silex: RIA developement tool - see http://silex-ria.org/

Silex is (c) 2007-2012 Silex Labs and is released under the GPL License:

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License (GPL) as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/
/* TODO Add Natural docs comments
*  TODO add logger and logging instructions adapted to production
*  TODO add CSS
*  TODO : when check rights, maybe check some function availability also ?
*  TODO : exclude list doesn't work when we do not start the path by '/'
*/
set_include_path(get_include_path() . PATH_SEPARATOR . "../../");

require_once 'rootdir.php';
set_include_path(get_include_path() . PATH_SEPARATOR . ROOTPATH.'cgi/library/');
require_once ROOTPATH.'cgi/includes/version_editor.php';
require_once ROOTPATH.'cgi/includes/consts.php';

if( isset($_POST["rights_ok"]) )
{
	if( isset($_POST["file_list_size"]) )
	{
		// Here we simply generate the version.xml with the information gathered in previous steps
		
		$excludePaths = array();
		$requirePaths = array();
		for($u=1; $u<=$_POST["file_list_size"]; $u++)
		{
			if(empty($_POST[$u."_include"]))
				$excludePaths[] = $_POST[$u."_path"];
			else if(isset($_POST[$u."_require"]))
				$requirePaths[] = $_POST[$u."_path"];
		}
		
		$silexTree = SilexTree::createFromFileTree($excludePaths, $requirePaths);
		$silexTree->version = $_POST["version_tag"];
		$silexTree->saveVersion( ROOTPATH . urldecode($_POST["version_file_path"]) );
		
		print "<span style='font-style:italic; color:green;'>Your version file has just been successfully generated under ".urldecode($_POST["version_file_path"])."</span>";
		
		if(!empty($excludePaths))
		{
			print "<br><span style='font-style:italic; color:green;'>The following paths have been excluded from it :<br></span>";
			foreach($excludePaths as $excludedPath)
				print "<font face='courier new' size='1'>".$excludedPath."</font><br>";
		}
			
	} else {
		// We browse the entire Silex tree structure and return the list of files in it. 
		// For each file we print two checkboxes : one telling to the script if we include the file in the version.xml or not; another one telling if we set the "updateRequired" tag to true or false
		// While generating the file list, we uncheck by default all the "files to exclude" set within the exclude_list parameter of the plugin (see plugin's main class)
		// The checkboxes of all the other files will be checked
		
		print "<span style='font-style:italic; color:green;'>Your PHP process has the required access rights on your Silex server file tree to ".
			"generate the XML version file.</span>".
			"<p>Please choose now which files to include in the new version and which files will have to be absolutely updated by".
			"the users in order to consider that their update is consistent:</p>";
		
		$pathsToExclude = null;
		if(!empty($_POST["exclude_list"]))
			$pathsToExclude = explode( ':' , urldecode($_POST["exclude_list"]) );
		
		$silexTree = SilexTree::createFromFileTree();
		
		print "<script type=\"text/javascript\">
			function animBrowse(Index)
			{
				if($(\"#button_folder_\"+Index).val() == '-')
				{
					$(\"#div_height_\"+Index).val( $(\"#folder_\"+Index).height() );
					$(\"#folder_\"+Index).animate( { height: 0 }, 250, function() { $(\"#folder_\"+Index).hide(); $(\"#button_folder_\"+Index).val(\"+\"); } );
				} else {
					$(\"#folder_\"+Index).animate( { height: $(\"#div_height_\"+Index).val() }, 250, function() { $(\"#folder_\"+Index).height('auto'); $(\"#folder_\"+Index).show(); $(\"#button_folder_\"+Index).val(\"-\"); } );
				}
			}
			function updateRequire(Index)
			{
				if($(\"#include_\"+Index).attr('checked'))
				{
					$(\"#require_\"+Index).attr('checked', 'checked');
					$(\"#require_\"+Index).removeAttr('disabled');
				} else {
					$(\"#require_\"+Index).removeAttr('checked');
					$(\"#require_\"+Index).attr('disabled', 'disabled');
				}
			}
			function updateInnerItems(Index)
			{
				if($(\"#include_\"+Index).attr('checked'))
				{
					$(\".reqChecks_\"+Index).removeAttr('disabled');
					$(\".checks_\"+Index).attr('checked', 'checked');
				} else {
					$(\".checks_\"+Index).removeAttr('checked');
					$(\".reqChecks_\"+Index).attr('disabled', 'disabled');
				}
			}
			</script>";
		
		print "<form id='file_list_checked'>";
		print "<font face='courier new' size='2'>";
		
		print "<div style='width:100%;>".
			"<div style='width:100%;'>". // TODO modify titles to images
				"<div style='width:90%; text-align:center; float:left;'><b>Path</b></div>".
				"<div style='width:5%; text-align:center; float:right;'><b>I.</b></div>".
				"<div style='width:5%; text-align:center; float:right;'><b>R.</b></div>".
				"<div style='clear:both;'></div>".
			"</div>"; 
		$i = outputFolderModel($silexTree->rootFolder, 0, $pathsToExclude);
		print "</div>";
		
		print "</font>";
		
		print "<input class='params' type='hidden' name='exclude_list' value='".$_POST["exclude_list"]."' > ".
				"<input class='params' type='hidden' name='version_file_path' value='".$_POST["version_file_path"]."' > ".
				"<input class='params' type='hidden' name='version_tag' value='".$_POST["version_tag"]."' > ".
				"<input class='params' type='hidden' name='plugin_name' value='".$_POST["plugin_name"]."' > ".
				"<input class='params' type='hidden' name='rights_ok' id='rights_ok' value='OK' > ".
				"<input class='params' type='hidden' name='file_list_size' value='".$i."' >";
		print "</form>";
		
		print '<input type="button" value="SUBMIT" '.
				'onclick="javascript:$.post( \'plugins/'.$_POST["plugin_name"].'/generate_version.php\', '.
				'$(\'.path\').serialize()+\'&\'+$(\'.checkInc\').serialize()+\'&\'+$(\'.checkReq\').serialize()+\'&\'+$(\'.params\').serialize()'.
				'	, function( data ) { $(\'#'.$_POST["plugin_name"].'\').html(data); } );" > ';
	}
}
else
{	
	$silexTree = new SilexTree();
	
	$rights = array(READ_RIGHTS);
	
	$results = $silexTree->checkRights($rights);
	
	if(!empty($results))
	{
		print "<input type=\"button\" value=\"RE-CHECK FILE ACCESS RIGHTS\" 
			onclick=\"javascript:$.post( 'plugins/".$_POST["plugin_name"]."/generate_version.php', 
			{
				exclude_list: '".$_POST["exclude_list"]."', 
				version_file_path: '".$_POST["version_file_path"]."',
				version_tag: '".$_POST["version_tag"]."',
				plugin_name: '".$_POST["plugin_name"]."'
			}, function( data ) { $('#".$_POST["plugin_name"]."').html(data); } );\"> ";

		print "<p style='font-weight:bold; color:red;'>The following folders/files have too much restricted permissions to allow the version file generation. 
			Please adjust them accordingly to allow the generation of your XML version file.</p>";
		
		print "<font face='courier new' size='2'>";
		foreach($results as $result)
		{
			print $result->path.$result->name."<br>";
		}
		print "</font>";
	}
	else
	{
		$versionFile = new FileModel( urldecode($_POST["version_file_path"]) );
		
		if(!$versionFile->checkRights(array(WRITE_RIGHTS)))
		{
			print "<input type=\"button\" value=\"RE-CHECK FILE ACCESS RIGHTS\" 
			onclick=\"javascript:$.post( 'plugins/".$_POST["plugin_name"]."/generate_version.php', 
			{
				exclude_list: '".$_POST["exclude_list"]."', 
				version_file_path: '".$_POST["version_file_path"]."',
				version_tag: '".$_POST["version_tag"]."',
				plugin_name: '".$_POST["plugin_name"]."'
			}, function( data ) { $('#".$_POST["plugin_name"]."').html(data); } );\"> ";
			
			print "<p style='font-weight:bold; color:red;'>Your server do not have the \"write\" access rights to ".urldecode($_POST["version_file_path"]).". 
			Please adjust it accordingly to allow the generation of your XML version file.</p>";
		}
		else
		{
			print "
			<script>
				$.post( 'plugins/".$_POST["plugin_name"]."/generate_version.php', 
					{
						exclude_list: '".$_POST["exclude_list"]."', 
						version_file_path: '".$_POST["version_file_path"]."',
						version_tag: '".$_POST["version_tag"]."',
						plugin_name: '".$_POST["plugin_name"]."',
						rights_ok: 'OK'
					}, 
					function( data ) { $('#".$_POST["plugin_name"]."').html(data); } );
			</script>";
		
		}
	}
}

function outputFolderModel($folderModel, $i, $pathsToExclude=null, $includeChecked=null, $checkboxClass="", $requireCheckboxClass="")
{
	$i++; $checkboxClass.=" checks_$i"; $requireCheckboxClass.=" reqChecks_$i";
	
	$includeChecked = shouldIncludeBeChecked($folderModel->path.$folderModel->name, $pathsToExclude, $includeChecked);
			
	print 	"<div>".
				"<div style='float:left;'><input type='hidden' id='div_height_".$i."' value='' >"."<input type='button' value='-' id='button_folder_".$i."' onclick='javascript:animBrowse(\"$i\")' ></div>".
				"<div style='float:left;'><input class='path' type='hidden' name='".$i."_path' value='".$folderModel->path.$folderModel->name."' >".$folderModel->name."</div>".
				"<div style='float:right; padding-right:20px;'><input class='checkInc $checkboxClass' name='".$i."_include' id='include_".$i."' type='checkbox' value='1' onClick='javascript:updateInnerItems(\"$i\")' $includeChecked ></div>".
				"<div style='clear:both;'></div>".
			"</div>";
	
	print "<div style='overflow-y:hidden; padding-left:15px;' id='folder_".$i."'>";
	
	foreach($folderModel->folders as $innerFolder)
		$i = outputFolderModel($innerFolder, $i, $pathsToExclude, $includeChecked, $checkboxClass, $requireCheckboxClass);
	
	foreach($folderModel->files as $innerFile)
	{
		$i++;
		$fileIncludeChecked = shouldIncludeBeChecked( $innerFile->path.$innerFile->name, $pathsToExclude, $includeChecked );
		if((empty($fileIncludeChecked))) $reqDisabled = 'disabled'; else $reqDisabled = '';
		
		print "<div>".
			"<div style='float:left;'><input class='path' type='hidden' name='".$i."_path' value='".$innerFile->path.$innerFile->name."' >".$innerFile->name."</div>".
			"<div style='float:right;'><input class='checkInc $checkboxClass $requireCheckboxClass' name='".$i."_require' id='require_".$i."' type='checkbox' value='1' $fileIncludeChecked $reqDisabled ></div>".
			"<div style='float:right;'><input class='checkReq $checkboxClass' name='".$i."_include' id='include_".$i."' type='checkbox' value='1' onClick='javascript:updateRequire(\"$i\")' $fileIncludeChecked ></div>".
			"<div style='clear:both;'></div>".
			"</div>";
	}
	
	print "</div>";
	
	return $i;
}

function shouldIncludeBeChecked($filePath, $pathsToExclude, $includeChecked)
{
	if($includeChecked === '')
		return $includeChecked;
		
	if(!empty($pathsToExclude))
		if( in_array( strtolower($filePath), $pathsToExclude ) || 
			in_array( DIRECTORY_SEPARATOR . strtolower($folderModel->path.$folderModel->name), $pathsToExclude ) || 
			in_array( substr( strtolower($folderModel->path.$folderModel->name) , 1) , $pathsToExclude ) )
			return '';
	
	return 'checked';
}

?>
