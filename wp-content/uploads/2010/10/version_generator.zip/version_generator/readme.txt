notes for version generator plugin - by Thomas F�tiveau (thomas.fetiveau.tech@gmail.com)
----------------------------------------------------------------

The version generator plugin is used to generate a new version of Silex for the user to update from. It is not reserved to Silex core team: you can have your own version of Silex distributed and your users will update with your versions.

Please read this to understand the update system of Silex
> http://community.silexlabs.org/silex/codex/?page_id=76

The update system will is made of three parts :

- Silex plugin that generates the version.xml file for a given Silex version. It is used only by the publisher of a new Silex versions.
- php service on the update server, that distributes the files to update,
- Silex plugin, client part of the updater. This plugin does the main jobs of the updating tasks : it calls the remote update service, find out which files are to update, manage user modifyed/added files during the update�

Instructions: how to generate a version of Silex server

Ci-dessous les �tapes � suivre pour g�n�rer un version.xml correct avec la version du plugin generator actuelle :

Faire une copie du plugin_server.php (dans lՎtat dans lequel on veut le distribuer aux utilisateurs lors de leurs updates)
Activer et param�trer le version_generator (ne pas oublier de renseigner le param�tre version_tag)
Lancer la premi�re �tape de la g�n�ration (listing des fichiers/dossiers) en cliquant sur �LAUNCH FILE ACCESS RIGHTS CHECK�
A ce moment, si les droits d�acc�s aux fichiers le permettent, une liste des dossiers et fichiers devrait appara�tre. A ce moment, remplacer le fichier plugin_server.php de votre silex_server par celui que vous avez sauvegard� � lՎtape 1.
Cocher-d�cocher les fichiers et dossiers selon ce que l�on veut inclure dans la version. La premi�re checkbox correspond � �est-ce que l�on inclue le fichier/dossier dans la version ? coch�=>oui, d�coch�=>non� et la deuxi�mecheckbox correspond � �est-ce que ce fichier devra �tre absolument updater par les utilisateurs ? coch�=>oui, d�coch�=>non� A cette �tape, v�rifier que le fichier pass.php et le dossier plugins/version_generator ne sont pas inclus (premi�re checkbox d�coch�e, deuxi�me disabled).
Lorsque toutes les inclusions et tags updateRequired vous conviennent, lancez la generation du version.xml en cliquant sur SUBMIT en bas de la liste
Allez v�rifier ensuite si le version.xml a bien �t� g�n�r� (en principe oui, mais comme on est en phase de test�) en v�rifiant la date et l�heure de cr�ation du fichier et en v�rifiant son contenu (il ne doit pas contenir pass.php ni /plugins/version_generator)