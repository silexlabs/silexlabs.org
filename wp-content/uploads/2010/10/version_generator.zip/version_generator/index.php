<?php
/*
 This file is part of Silex: RIA developement tool - see http://silex-ria.org/

Silex is (c) 2007-2012 Silex Labs and is released under the GPL License:

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License (GPL) as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/
/**
* TODO add natural doc comments
* TODO create css file
* TODO add logger and logging instructions adapted to production
*/
require_once ROOTPATH.'cgi/includes/plugin_base.php';

class version_generator extends plugin_base
{
	/*
		Variable: $pluginScope
		The scope of the plugin. In the case of the version_generator, we have a plugin only for the "manager" scope: 100.
	*/
	protected $pluginScope = 4;

	/*
	   Function: initDefaultParamTable
	   Initialize the updater's parameters.
	*/
	function initDefaultParamTable()
	{
		$this->paramTable = array(
			array(
				"name" => "exclude_list",
				"label" => "Exclude list",
				"description" => "This is the list of files and/or directories to exclude by default from the version.xml. Separate each one with a :, for example file1:dir1:file2",
				"value" => "/conf/pass.php:/version.xml:/plugins/version_generator:/plugins/updater/temp_files",
				"restrict" => "",
				"type" => "string",
				"maxChars" => ""
			),
			array(
				"name" => "version_file_path",
				"label" => "Version file path",
				"description" => "This is the path where the version file will be generated.",
				"value" => "version.xml",
				"restrict" => "",
				"type" => "string",
				"maxChars" => ""
			),
			array(
				"name" => "version_tag",
				"label" => "Version tag",
				"description" => "This is the version tag you want to give the XML version file you will generate.",
				"value" => "",
				"restrict" => "",
				"type" => "string",
				"maxChars" => "30"
			)
		);
	}
	
	/*
		Function: getDescription
		Get the status of update of the the server (does it run the latest version?).
		
		Returns:
		The plugin's description string. 
	*/
	public function getDescription()
	{
		return "Version Generator";
	}
	
   	/**
	* Returns the html code corresponding to the administration page of the plugin.
	* In that case, we print a button that calls the generate_version.php script of the version_generator plugin
	* @return string
	*/
	public function getAdminPage()
	{
		$result = "
			<html>
				<body>
					
					<div style=\"float:left; width:50%;\">
					<img src='plugins/".$this->pluginName."/plugin.png' alt='".$this->pluginName."' /><br/><br/>
					</div>
					
					<div id=\"".$this->pluginName."_params\" style=\"float:left; width:50%; font-family:arial; font-size:small; padding-top:6px;\">
						Version generator's parameters values :<br />
						<div style='margin-left:10px;'>
							<font face='courier news' size='1'><br />".
							$this->paramTable[0]['name']." : ".$this->paramTable[0]['value']."<br />
							".$this->paramTable[1]['name']." : ".$this->paramTable[1]['value']."<br />
							".$this->paramTable[2]['name']." : ".$this->paramTable[2]['value']."
							</font>
						</div>
					</div>
					
					<div id=\"".$this->pluginName."\" style=\"clear:both; font-family:arial;\">
					
						<p>Before generating the version.xml for your current Silex server, we need to check the access rights of the PHP process 
							on your Silex server file tree:</p>
						
						<div style='width:100%; text-align:center;'>
						<input type=\"button\" value=\"LAUNCH FILE ACCESS RIGHTS CHECK\" onclick=\"javascript:$.post( 'plugins/".$this->pluginName."/generate_version.php', 
							{
								exclude_list: '".$this->refactorUrl( $this->refactorPath( $this->paramTable[0]['value'] ) )."',
								version_file_path: '".$this->refactorUrl( $this->refactorPath( $this->paramTable[1]['value'] ) )."',
								version_tag: '".$this->paramTable[2]['value']."',
								plugin_name: '".$this->pluginName."'
							}, function( data ) { $('#".$this->pluginName."').html(data); } );\"> 
						</div>
					</div>
					
				</body>
			</html>
			" ;
			
        return $result;
	}
	
	private function refactorPath($stringToRefactor)
	{
		$refactoredString = str_replace( '/', DIRECTORY_SEPARATOR, $stringToRefactor);
		$refactoredString = str_replace( "\\", DIRECTORY_SEPARATOR, $refactoredString);
		$refactoredString = strtolower($refactoredString);
		return $refactoredString;
	}
	
	private function refactorUrl($stringToRefactor)
	{
		$refactoredString = strtolower($stringToRefactor);
		return urlencode($refactoredString);
	}
}

?>
