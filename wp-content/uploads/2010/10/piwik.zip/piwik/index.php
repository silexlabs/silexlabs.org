<?php
/*
 This file is part of Silex: RIA developement tool - see http://silex-ria.org/

Silex is (c) 2007-2012 Silex Labs and is released under the GPL License:

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License (GPL) as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/
// include './rootdir.php'; we do not call rootdir.php for the moment as it's already within the filepath. Also this includes seems to break the administration part of the plugin. If we notice some cases where ROOTPATH isn't known when we call index.php, we will have to rethink this part.
require_once ROOTPATH.'cgi/includes/plugin_base.php';

class piwik extends plugin_base
{
	
	function initDefaultParamTable()
	{
		$this->paramTable = array( 
			array(
				"name" => "piwikAddress",
				"label" => "Piwik Address",
				"description" => "This is the address of your Piwik server. For more information, please see http://piwik.org",
				"value" => "",
				"restrict" => "",
				"type" => "string",
				"maxChars" => "200"
			),
			array(
				"name" => "siteID",
				"label" => "Site ID ",
				"description" => "This is the ID of your site in the Piwik system. For more information, please see http://piwik.org",
				"value" => "",
				"restrict" => "",
				"type" => "string",
				"maxChars" => "100"
			),
			array(
				"name" => "htmlTitle",
				"label" => "HTML title of your site",
				"description" => "This is the HTML title of your site. You can set it also in the Properties section of the manager.",
				"value" => "",
				"restrict" => "",
				"type" => "string",
				"maxChars" => "200"
			)
		);
	}
	
	public function initHooks($hookManager)
	{
		$hookManager->addHook('index-body-end', array($this, 'open_silex_page_index_body_end_hook'));
	}
	

    public function getAdminPage($siteName)
	{
		$result = "<html><body><iframe width=\"800\" height=\"3400\" frameborder=\"0\"  vspace=\"0\"  hspace=\"0\"  marginwidth=\"0\"
					marginheight=\"0\" scrolling=no src=\"http://piwik.org\" /></body></html>" ;
        return $result;
    }
	
	/**
	 * Silex hook for the script tag
	 */
	public function open_silex_page_index_body_end_hook()
	{
		global $id_site;
		
		$i = 0;
		while( $i < count( $this->paramTable ) )
		{
			if($this->paramTable[$i]["name"] == "piwikAddress")
				$piwikAddress = $this->paramTable[$i]["value"];
			else if($this->paramTable[$i]["name"] == "siteID")
				$siteID = $this->paramTable[$i]["value"];
			else if($this->paramTable[$i]["name"] == "htmlTitle")
				$title = $this->paramTable[$i]["value"];
			$i++;
		}

		?>
			<script type="text/javascript">
				function open_silex_page_piwik($event)
				{
					var piwikTracker = Piwik.getTracker();
					piwikTracker.setDocumentTitle("<?php echo $title; ?> - "+$event.hashValue);
					piwikTracker.setCustomUrl("<?php echo $id_site; ?>/"+$event.hashValue);
					piwikTracker.setSiteId( <?php echo $siteID;?>);
					piwikTracker.setTrackerUrl( "<?php echo $piwikAddress; ?>piwik.php");
					piwikTracker.trackPageView();
				}
				silexNS.HookManager.addHook("openSilexPage",open_silex_page_piwik);
				
				// load the base script
				silexNS.SilexApi.addScript("<?php echo $piwikAddress;?>piwik.js");
				silexNS.SilexApi.includeJSSCripts(doPiwikAnalyticsTool);
				
							
				function doPiwikAnalyticsTool()
				{
					var piwikTracker = Piwik.getTracker();
					piwikTracker.trackPageView();
				}
			</script>
		<?php
	}
	
}

?>
