notes for yahoo_analytics_plugin
----------------------------------------------------------------
This is a yahoo web analytics plugin. 
Yahoo Web Analytics (YWA) was made available to Yahoo�s search and display advertisers who are supported by dedicated Yahoo account teams, after Yahoo acquired web analytics software IndexTools.


INSTALLATION INSTRUCTIONS

To install it, drop the yahoo_analytics folder in the silex /plugins folder, 

You can activate it for a specific site or for the entire Silex server (for all sites hosted by your Silex server) through the Silex manager. Otherwise, you can do the same manually :

 - To activate this plugin manually for specific site, add it to the PLUGINS_LIST parameter of your site in contents/[your_site]/conf.txt. Each plugin listed in this parameter is separated by the character @

   ex : PLUGINS_LIST=wysiwyg@search@yahoo_analytics&

   To configure this plugin, also set the below parameters:  
   
    YWAPid=Account number of YWA&

 - To activate it manually at the Silex server level : edit the /conf/plugins_server.php file and add it to the $conf['PLUGINS_LIST'] parameter
 
   ex : $conf['PLUGINS_LIST'] = 'wysiwyg@snapshot@yahoo_analytics';
   
   To configure it, set the below parameter:  
   
	$conf['YWAPid'] = 'Account number of YWA';


It is made up of :
- index.php : contains the php and js necessary to load the plugin. It waits for the hook open_silex_page_yahoo_analytics to be called.

