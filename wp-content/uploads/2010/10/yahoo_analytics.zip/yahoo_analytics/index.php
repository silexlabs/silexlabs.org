<?php
/*
 This file is part of Silex: RIA developement tool - see http://silex-ria.org/

Silex is (c) 2007-2012 Silex Labs and is released under the GPL License:

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License (GPL) as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/
// include './rootdir.php'; we do not call rootdir.php for the moment as it's already within the filepath. Also this includes seems to break the administration part of the plugin. If we notice some cases where ROOTPATH isn't known when we call index.php, we will have to rethink this part.
require_once ROOTPATH.'cgi/includes/plugin_base.php';

class yahoo_analytics_management extends plugin_base
{
	
	function initDefaultParamTable()
	{
		$this->paramTable = array( 
			array(
				"name" => "YWAPid",
				"label" => "Yahoo analytics ID",
				"description" => "This is your Yahoo analytics ID. For more information, please see http://web.analytics.yahoo.com",
				"value" => "",
				"restrict" => "",
				"type" => "string",
				"maxChars" => "100"
			)
		);
	}
	
	public function initHooks($hookManager)
	{
		$hookManager->addHook('index-body-end', array($this, 'open_silex_page_index_body_end_hook'));
	}


    public function getAdminPage($siteName)
	{
		$result = "<html><body><iframe width=\"1000\" height=\"850\" frameborder=\"0\"  vspace=\"0\"  hspace=\"0\"  marginwidth=\"0\"
					marginheight=\"0\" scrolling=no src=\"http://web.analytics.yahoo.com\" /></body></html>" ;
        return $result;
    }
	
	/**
	 * Silex hook for the script tag
	 */
	public function open_silex_page_index_body_end_hook()
	{
		global $id_site;
		global $ROOTURL;
		
		$i = 0;
		while( $i < count( $this->paramTable ) && $this->paramTable[$i]["name"] != "YWAPid") $i++;
		$YWAPid = $this->paramTable[$i]["value"];
		
		?>
			<script type="text/javascript">
				function open_silex_page_yahoo_analytics($event)
				{
					var YWATracker = YWA.getTracker("<?php echo $YWAPid; ?>");
					YWATracker.setDocumentName($event.hashValue);
					YWATracker.setUrl("<?php echo $ROOTURL.'?/'.$id_site ?>/"+$event.hashValue);
					YWATracker.submit();
				}
				silexNS.HookManager.addHook("openSilexPage",open_silex_page_yahoo_analytics);
				
				// load the base script
				silexNS.SilexApi.addScript("http://d.yimg.com/mi/ywa.js");
				silexNS.SilexApi.includeJSSCripts(doYahooAnalyticsTool);		
							
				function doYahooAnalyticsTool()
				{		
				}
				
			</script>
		<?php
	}
	
}

?>
