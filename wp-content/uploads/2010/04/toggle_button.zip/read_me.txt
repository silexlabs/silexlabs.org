______________________________________________________
___________________English____________________________
______________________________________________________


A toggle button allows to distinguish in a visual way (by two different colors or shapes for instance) if the end user is on the page which is selected by this button or if he is on an other page of the website.

In this folder, an exemple of this component is ready to use. It is the toggle_button.cmp.swf file. To use it in a website, you have to put it in the media folder of the silex server to find it in the library at the website production step.

To customize the button, you have to put the toggle_button.cmp.fla and toggle_button.as files in the silex_dev_kit in the components/buttons folder.

in the library of Flash :
 - the default button correspond to button's state for all pages of the website, except the page which is calledby this button.
 - the over button correspond to button's state for the page which is selected by this button.

It is necessary to only modify those two buttons in function of the desired aspect.

**********************************************************************
AUTHOR : Solvejg Bougeois => http://solveig.bougeois.free.fr


______________________________________________________
___________________Fran�ais___________________________
______________________________________________________


Un "toggle bouton" est un bouton � deux �tats qui permet de distinguer visuellement (par deux couleurs ou deux formes diff�rentes par exemple) si l'utilisateur est sur la page point�e par ce bouton ou sur toute autre page du site.



Dans ce dossier, un exemple de ce composant est pr�t � l'emploi. il s'agit du fichier toggle_button.cmp.swf.
Pour l'utiliser dans un site, le mettre dans le dossier media du serveur pour pouvoir le retrouver ensuite dans la librairie lors de la r�alisation du site.


Pour personnaliser le bouton, mettre les fichiers toggle_button.cmp.fla et Toggle_button.as dans le silex_dev_kit dans le dossier components/buttons.

Dans la biblioth�que : 
 - le bouton default correspond � l'�tat qu'a le bouton pour toute les pages du site, exept�e la page coprrespondant � ce dit bouton.
 - le bouton over correspond � l'�tat qu'a le bouton lorsque la page qu'il pointe est ouverte.

Il est n�cessaire donc de modifier seulement ces deux boutons en fonction de l'aspect voulu.


**********************************************************************
Composant cr�� par Solvejg Bougeois => http://solveig.bougeois.free.fr