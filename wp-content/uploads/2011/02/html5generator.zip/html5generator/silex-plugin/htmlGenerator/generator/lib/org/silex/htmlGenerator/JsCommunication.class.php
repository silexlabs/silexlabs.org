<?php

class org_silex_htmlGenerator_JsCommunication {
	public function __construct(){}
	static $actions;
	function __toString() { return 'org.silex.htmlGenerator.JsCommunication'; }
}
org_silex_htmlGenerator_JsCommunication::$actions = new _hx_array(array());
