<?php

{
	require_once("cgi/includes/ComponentDescriptor.php");
	null;
}
