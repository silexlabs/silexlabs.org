<?php

{
	require_once("cgi/includes/plugin_manager.php");
	null;
}
