<?php

{
	require_once("cgi/includes/server_content.php");
	null;
}
