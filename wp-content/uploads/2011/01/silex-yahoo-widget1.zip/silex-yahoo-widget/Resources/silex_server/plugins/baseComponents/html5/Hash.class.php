<?php
/*
This file is part of Silex - see http://projects.silexlabs.org/?/silex

Silex is � 2010-2011 Silex Labs and is released under the GPL License:

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License (GPL) as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/
class Hash implements IteratorAggregate{
	public function __construct() {
		if( !php_Boot::$skip_constructor ) {
		$this->h = array();
		;
	}}
	public $h;
	public function set($key, $value) {
		$this->h[$key] = $value;
		;
	}
	public function get($key) {
		if(array_key_exists($key, $this->h)) {
			return $this->h[$key];
			;
		}
		else {
			return null;
			;
		}
		;
	}
	public function exists($key) {
		return array_key_exists($key, $this->h);
		;
	}
	public function remove($key) {
		if(array_key_exists($key, $this->h)) {
			unset($this->h[$key]);
			return true;
			;
		}
		else {
			return false;
			;
		}
		;
	}
	public function keys() {
		return new _hx_array_iterator(array_keys($this->h));
		;
	}
	public function iterator() {
		return new _hx_array_iterator(array_values($this->h));
		;
	}
	public function toString() {
		$s = "{";
		$it = $this->keys();
		$�it = $it;
		while($�it->hasNext()) {
		$i = $�it->next();
		{
			$s .= $i;
			$s .= " => ";
			$s .= Std::string($this->get($i));
			if($it->hasNext()) {
				$s .= ", ";
				;
			}
			;
		}
		}
		return $s . "}";
		unset($s,$it);
	}
	public function getIterator() {
		return $this->iterator();
		;
	}
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->�dynamics[$m]) && is_callable($this->�dynamics[$m]))
			return call_user_func_array($this->�dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call �'.$m.'�');
	}
	function __toString() { return $this->toString(); }
}
