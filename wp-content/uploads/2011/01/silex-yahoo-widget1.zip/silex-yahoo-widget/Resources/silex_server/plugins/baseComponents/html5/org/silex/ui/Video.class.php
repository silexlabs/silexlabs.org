<?php
/*
This file is part of Silex - see http://projects.silexlabs.org/?/silex

Silex is � 2010-2011 Silex Labs and is released under the GPL License:

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License (GPL) as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/
class org_silex_ui_Video extends org_silex_ui_UiBase {
	public function __construct() {
		if( !php_Boot::$skip_constructor ) {
		parent::__construct();
		;
	}}
	public $scale;
	public $autoPlay;
	public $autoSize;
	public $loop;
	public $showNavigation;
	public $bufferSize;
	public $mute;
	public $volume;
	public $useHandCursor;
	public $fadeInStep;
	public function returnHTML() {
		if(_hx_explode(".", $this->url)->pop() === "flv") {
			return ((((((((((("<object width=\"" . $this->width) . "\" height=\"") . $this->height) . "\">\x0A\x09\x09\x09<param name=\"movie\" value=\"") . $this->url) . "\">\x0A\x09\x09\x09<embed src=\"") . $this->url) . "\" width=\"") . $this->width) . "\" height=\"") . $this->height) . "\">\x0A\x09\x09\x09</embed>\x0A\x09\x09\x09</object>";
			;
		}
		else {
			return ((((((((((("<video style='width:" . $this->width) . "px;height:") . $this->height) . "px;' src='") . $this->url) . "' width='") . $this->width) . "' height='") . $this->height) . "'") . (org_silex_ui_Video_0($this))) . "></video>";
			;
		}
		;
	}
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->�dynamics[$m]) && is_callable($this->�dynamics[$m]))
			return call_user_func_array($this->�dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call �'.$m.'�');
	}
	function __toString() { return 'org.silex.ui.Video'; }
}
;
function org_silex_ui_Video_0(&$�this) {
if($�this->showNavigation) {
	return " controls='controls'";
	;
}
else {
	return "";
	;
}
}