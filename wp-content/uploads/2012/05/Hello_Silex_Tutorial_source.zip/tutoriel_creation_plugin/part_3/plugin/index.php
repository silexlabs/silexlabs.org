<?php

require_once ROOTPATH.'cgi/includes/plugin_base.php';

class helloSilex_management extends plugin_base

{
	function initDefaultParamTable()
	{
		$this->paramTable = array( 
				array(
					"name" => "helloSilex_text",
					"label" => "helloSilex Text",
					"description" => "This is the text of the hello silex plugin",
					"value" => "HELLO SILEX !",
					"restrict" => "",
					"type" => "string",
					"maxChars" => "200"
				)
			);
	}

	public function initHooks($hook_manager)
	{
		$hook_manager->add_hook('index-body-end', 'hello_silex_index_body_end_hook', $this);
	}

	public function hello_silex_index_body_end_hook()
	{
	
		$i = 0;
		while( $i < count( $this->paramTable ) )
		{
			if($this->paramTable[$i]["name"] == "helloSilex_text")
				$helloSilexText = $this->paramTable[$i]["value"];
			$i++;
		}
		
	?>  

		<script type="text/javascript">

		silexNS.HookManager.addHook("silexAdminApiReady",initHelloSilex);
		silexNS.HookManager.addHook("getViewMenuItems",set_view_menu_item);
		
			function initHelloSilex()
			{
				document.getElementById('silex').SetVariable('silex_exec_str','load_clip:plugins/helloSilex/helloSilex.swf,plugins');
				
			}
			
			function toggle_hello_silex_visibility()
			{
				document.getElementById('silex').changeHelloSilexText("<?php echo $helloSilexText ?> ");
				document.getElementById('silex').toggleHelloSilexVisibility();
			}
			
			function set_view_menu_item(event)
			{
				event.data.push($rootUrl+"plugins/helloSilex/helloSilex_ViewMenu_Button.swf");
			}

		</script>

	<?php	
	}

}

?>