<?php

require_once ROOTPATH.'cgi/includes/plugin_base.php';

class helloSilex_management extends plugin_base

{

	public function initHooks($hook_manager)
	{
		$hook_manager->add_hook('index-body-end', 'hello_silex_index_body_end_hook', $this);
	}

	public function hello_silex_index_body_end_hook()
	{
	?>  

		<script type="text/javascript">

		silexNS.HookManager.addHook("preloadDone",initHelloSilex);
		
			function initHelloSilex()
			{
				document.getElementById('silex').SetVariable('silex_exec_str','load_clip:plugins/helloSilex/helloSilex.swf,plugins');
			}

		</script>

	<?php	
	}

}

?>