
Description
This component let you clip a media in a corner or on a side of the window. For example you can put your logo in the bottom right corner or a menu on the left side of the window, even if your website does not resize.
It is also possible to clip a media on an other one, e.g. a background on a text field.

 - Work only for website in noScale mode for now -

Installation
Unzip files and put the swf file somewhere the media/ folder or in a subfolder. Then drag it from the library toolbox to the scene.

Use
Set the "Name of the media" parameter to the name of a media.

Here is an explanation of the value parameters:
Left value 
- 1st line = x position, for example <<stageRect.left>> for the left side of the window.
- 2nd linie = left margin in pixels 
Top value
- 1st line = y position, for example <<stageRect.top>> for the top of the window.
- 2nd linie = top margin in pixels
Right value
- 1st line = x position of the right side of the media, for example <<stageRect.right>> for the right side of the window. If Left value is set, then the media is resized.
- 2nd linie = right margin in pixels
Bottom value
- 1st line = y position of the bottom of the media, for example <<stageRect.bottom>> for the bottom of the window. If Top value is set, then the media is resized.
- 2nd linie = bottom margin in pixels

To do
- showAll compatible
- more simple params (top left value / top left margin, ...)
