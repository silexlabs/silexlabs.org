<?php
/*
	this file is part of SILEX
	SILEX : RIA developement tool - see http://silex-ria.org/

	SILEX is (c) 2004-2007 Alexandre Hoyau and is released under the GPL License:

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License (GPL)
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/
/**
 * use PHPExcel to retrieve values from calculation of an Excel sheet 
 * results an xml feed with all the desired cells
 *
 * to do:
 * - security check of inputs and read rights
 *
 * @param		set_values	a suite of cell names and value pairs - e.g. C1:21,C2:test,C3:6
 * @param		get_values	values to be retrurned - may be a range - e.g. A1,C2-F15,G6
 * @param		file_name	name of the xlsx file
 * @param		sheet_number sheet number - default is 0
 * @example	excel_compute.php?set_values=C3:654,C4:444&get_values=C11&file=media/btt.xlsx => retrieve the value of C11 when C3 is set to 654 and C4 is set to 444
 * @example	excel_compute.php?set_values=C3:333,C4:444&get_values=C11,C13,C14&file_name=media/btt.xlsx
 */
set_include_path(get_include_path() . PATH_SEPARATOR . "../../");
set_include_path(get_include_path() . PATH_SEPARATOR . "../includes/");
set_include_path(get_include_path() . PATH_SEPARATOR . "../includes/phpexcel");
require_once("rootdir.php");
require_once("server_config.php");
require_once("file_system_tools.php");

define("ROWS", "rows");
define("COLUMNS", "columns");
define("NONE", "none");

$logger = new logger("excel_compute");
$fst = new file_system_tools();

// inputs
if (isset($_POST["file_name"]))
	$file_name=$_POST["file_name"];
else
	if (isset($_GET["file_name"]))
		$file_name=$_GET["file_name"];
	else
	{
		echo "<b>You need to provide the path of the file you want to use</b><br> cgi/scripts/excel_compute.php?file_name=media/test_xls.xlsx&get_values=H7<br />or<br />cgi/scripts/excel_compute.php?set_values=H3:25,H4:38&get_values=H7,H8,H10,H12&file_name=media/test_xls.xlsx";
		echo "<br />";
		echo "<br />";
		echo "<b>The parameters can be passed through GET or POST and are the following:</b><br>";
		echo "<br />- set_values	a suite of cell names and value pairs - e.g. C1:21,C2:test,C3:6";
		echo "<br />- get_values	values to be retrurned - may be a range - e.g. A1,C2-F15,G6";
		echo "<br />- file_name	name of the xlsx file";
		echo "<br />- sheet_number sheet number - default is 0";
		echo "<br />- combine_items_from . You can combine items from rows, columns, or not combine at all. accepted values : rows, columns, none. default is rows";
		echo "<br />- example	excel_compute.php?set_values=C3:654,C4:444&get_values=C11&file=media/btt.xlsx => retrieve the value of C11 when C3 is set to 654 and C4 is set to 444";
		echo "<br />- example	excel_compute.php?set_values=C3:333,C4:444&get_values=C11,C13,C14&file_name=media/btt.xlsx";
		exit(0);
	}

$ext = substr($fileName, strrpos($fileName, '.') + 1);

// Class requirements
require_once('PHPExcel.php');
if($ext=="xlsx")
	require_once('PHPExcel/Reader/Excel2007.php');
else
	require_once('PHPExcel/Reader/Excel5.php');

// check rights to read this file
if ($fst->checkRights($fst->sanitize(ROOTPATH.$file_name),constant("file_system_tools::USER_ROLE"),constant("file_system_tools::READ_ACTION"))===FALSE)
{
	echo 'Error: No rights to read '.$file_name;
	exit(0);
}
if (isset($_POST["set_values"]))
	$set_values=$_POST["set_values"];
else
	if (isset($_GET["set_values"]))
		$set_values=$_GET["set_values"];
	else
	{
		$set_values = '';
	}
if (isset($_POST["get_values"]))
	$get_values=$_POST["get_values"];
else
	if (isset($_GET["get_values"]))
		$get_values=$_GET["get_values"];
	else
	{
		echo "error: get_values is missing";
		exit(0);
	}
if (isset($_POST["sheet_number"]))
	$sheet_number=$_POST["sheet_number"];
else
	if (isset($_GET["sheet_number"]))
		$sheet_number=$_GET["sheet_number"];
	else
	{
		// default
		$sheet_number=0;
	}
		
if (isset($_POST["combine_items_from"]))
	$combine_items_from=$_POST["combine_items_from"];
else
	if (isset($_GET["combine_items_from"]))
		$combine_items_from=$_GET["combine_items_from"];
	else
	{
		// default
		$combine_items_from=ROWS;
	}
		
if(($combine_items_from != ROWS) && ($combine_items_from != COLUMNS) && ($combine_items_from != NONE) ){
	throw new Exception("onBadValueForCombineItemsFrom");
}	
// Load calculation spreadsheet
if($ext=="xlsx")
	$objReader = new PHPExcel_Reader_Excel2007();
else
	$objReader = new PHPExcel_Reader_Excel5();
	
$objPHPExcel = $objReader->load(ROOTPATH.$file_name);

// Set active sheet
$objPHPExcel->setActiveSheetIndex($sheet_number);

//print_r($objPHPExcel->getActiveSheet());

// Assign data
if ($set_values != '')
{
	$setValues_array=explode(",",$set_values);
	if ($setValues_array != FALSE)
	{
		foreach($setValues_array as $pair)
		{
			$pair_array=explode(":",$pair);
			$cell=$pair_array[0];
			$value=$pair_array[1];
			$objPHPExcel->getActiveSheet()->setCellValue($cell,$value);
		}
	}
}
/*
$objPHPExcel->getActiveSheet()->setCellValue('C3', '654');
$objPHPExcel->getActiveSheet()->setCellValue('C13', '=S18');
$objPHPExcel->getActiveSheet()->setCellValue('C3', '=S18');
*/

// compute url base
$scriptUrl=$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
$server_config = new server_config();
$lastSlashPos=strrpos($scriptUrl,$server_config->silex_server_ini["CGI_SCRIPTS_FOLDER"]."rss_browse_folder.php");
$urlBase="http://".substr($scriptUrl,0,$lastSlashPos);
//**
// echo rss
header('Content-Type: text/xml; charset=UTF-8');

echo '<?xml version="1.0" encoding="UTF-8"?>';
?><rss version="2.0"
	xmlns:content="http://purl.org/rss/1.0/modules/content/"
	xmlns:wfw="http://wellformedweb.org/CommentAPI/"
	xmlns:dc="http://purl.org/dc/elements/1.1/"
	xmlns:itunes="http://www.itunes.com/dtds/podcast-1.0.dtd"
	xmlns:media="http://search.yahoo.com/mrss/"
	xmlns:photo="http://www.pheed.com/pheed/"
	xmlns:buyme="http://www.rugama.com/rss/1.0/modules/buyme/"
	xmlns:rateme="http://www.rugama.com/rss/1.0/modules/rateme/">
	<channel>
		<title>Results</title>
		<link><?php echo $urlBase; ?></link>
		<pubDate><?php date ("r") ?></pubDate>
		<lastBuildDate><?php date ("r") ?></lastBuildDate>
		<generator>http://www.silex-ria.org</generator>
<?php
// return results
$getValues_array=explode(",",$get_values);
foreach($getValues_array as $getValue)
{
//	echo $objPHPExcel->getActiveSheet()->getCell($getValue)->getCalculatedValue()."<br>";
	if (strpos($getValue,'-')===FALSE)
	{
		// single cell
?>
	<item>
		<title><![CDATA[<?php echo $objPHPExcel->getActiveSheet()->getCell($getValue)->getCalculatedValue(); ?>]]></title>
	</item>
<?php
	}
	else
	{
		// range of cells - vertical only is handled
		$range_values = explode("-",$getValue); 
		if ($range_values)
		{
			// split top cell letter and number
			$top_cell_name = $range_values[0];
			//echo match($top_cell_name,"[0-9]");
			$str_array = preg_split ('/[0-9]/',$top_cell_name,null,PREG_SPLIT_NO_EMPTY);
			$top_cell_letter = $str_array[0];
			$top_cell_number = substr($top_cell_name,strlen($top_cell_letter));
			echo "			" . $top_cell_letter . '+' . $top_cell_number . "\n";
			
			// split bottom cell letter and number
			$bottom_cell_name = $range_values[1];
			$str_array = preg_split ('/[0-9]/',$bottom_cell_name,null,PREG_SPLIT_NO_EMPTY);
			$bottom_cell_letter = $str_array[0];
			$bottom_cell_number = substr($bottom_cell_name,strlen($bottom_cell_letter));
			echo "			" . $bottom_cell_letter . '+' . $bottom_cell_number . "\n";
			
			// check that we are on a vertical
/*			if ($bottom_cell_letter != $top_cell_letter)
			{
				echo 'error: only vertical ranges are supported for output values: '.$getValue.' is not a vertical range';
			}
			else
			{*/
			// output all data in the range
			if($combine_items_from == ROWS){
				for($idx_number = (int)$top_cell_number; $idx_number<=(int)$bottom_cell_number; $idx_number++)
				{
					echo "		<item>\n";
					echo "			<title><![CDATA[" . $idx_number . "]]></title>\n";
					for($idx_letter = ord($top_cell_letter); $idx_letter<=ord($bottom_cell_letter); $idx_letter++)
					{
						$idx_letter_str = chr($idx_letter);
						$cellValue = $objPHPExcel->getActiveSheet()->getCell($idx_letter_str.(string)$idx_number)->getCalculatedValue();
						echo "			<" . $idx_letter_str . "><![CDATA[" . $cellValue . "]]></" . $idx_letter_str . ">\n";
					}
					echo "		</item>\n";
				}
			}else if($combine_items_from == COLUMNS){
				for($idx_letter = ord($top_cell_letter); $idx_letter<=ord($bottom_cell_letter); $idx_letter++)
				{
					echo "		<item>\n";
					echo "			<title><![CDATA[" . chr($idx_letter) . "]]></title>\n";
					for($idx_number = (int)$top_cell_number; $idx_number<=(int)$bottom_cell_number; $idx_number++)
					{
						$idx_letter_str = chr($idx_letter);
						$cellValue = $objPHPExcel->getActiveSheet()->getCell($idx_letter_str.(string)$idx_number)->getCalculatedValue();
						//need to add line because apparently using just the number is wrong. (It fails the firefox xml parser. to check!)
						echo "			<line" . $idx_number . "><![CDATA[" . $cellValue . "]]></line" . $idx_number . ">\n";
					}
					echo "		</item>\n";
				}
			}else if($combine_items_from == NONE){
				for($idx_letter = ord($top_cell_letter); $idx_letter<=ord($bottom_cell_letter); $idx_letter++)
				{
					for($idx_number = (int)$top_cell_number; $idx_number<=(int)$bottom_cell_number; $idx_number++)
					{
						$idx_letter_str = chr($idx_letter);
						$cellValue = $objPHPExcel->getActiveSheet()->getCell($idx_letter_str.(string)$idx_number)->getCalculatedValue();
						echo "		<item>\n";
						echo "			<title><![CDATA[" . $cellValue . "]]></title>\n";
						echo "		</item>\n";
					}
				}
			}
		}
	}
}

/*
echo " --- ".$objPHPExcel->getActiveSheet()->getCell('C3')->getCalculatedValue()." --- <br>";
echo " --- ".$objPHPExcel->getActiveSheet()->getCell('C13')->getValue()." ---<br>";
echo " --- ".$objPHPExcel->getActiveSheet()->getCell('C13')->getCalculatedValue()." --- ";
*/
?>	</channel>
</rss>