<?php
/*
	this file is part of OOF
	OOF : Open Source Open Minded Flash Components

	OOF is (c) 2008 Alexandre Hoyau and Ariel Sommeria-Klein. It is released under the GPL License:

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License (GPL)
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/
	

	require_once("logger.php");	
	require_once("../../conf/oof_db_config.php");
	//a class for accessing the oof database easily. reads the config, sets encoding, does some logging etc.
	class oof_db_connection{
	
		var $logger = null;
		var $sqlConnection = null;
		var $config = null;

		function oof_db_connection($loggerName){
			$this->logger = new logger("DB - " . $loggerName);
		}
		
		//private
		function connectToDb(){
			$this->logger->debug("connecting : , DB_HOST: ".DB_HOST.", DB_USER : ".DB_USER.", DB_PASSWORD : ".DB_PASSWORD.", DB_NAME : ".DB_NAME);
			$this->sqlConnection = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
			if(!$this->sqlConnection){
				$mess = "result=error:" . mysql_error()."- request id:$request_id";
				throw new Exception($mess);
			}
			if(!mysql_select_db(DB_NAME, $this->sqlConnection)){
				$mess = "result=error:" . mysql_error()."- request id:$request_id";
				throw new Exception($mess);
			}
		
		}
		
		/**
		* oofSqlQuery
		* @param String query
		 * @returns RecordSet
		* logs then executes sql query
		*/
		
		function oofSqlQuery($query){
			if($this->sqlConnection == null){
				$this->connectToDb();
			}
			
			$this->logger->info("oof sql query : ".$query);
			$ret = mysql_query($query, $this->sqlConnection);
			if(!$ret){
				$errorMessage = "error executing query : ".$query."\nError code : ".mysql_errno($this->sqlConnection) . "\nError text : " . mysql_error($this->sqlConnection);
				throw new Exception($errorMessage);
			}
			
			return $ret;
		}    

	
	
	
	}