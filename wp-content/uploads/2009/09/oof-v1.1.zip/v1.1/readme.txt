Hi, 
to install OOF, you should probably get Silex first at http://silex-ria.org. OOF will be made more standalone in the future, but in the meantime, we advise you to use it with Silex.
http://sourceforge.net/projects/silex/files/ 

If you're lost, you're not alone. Check the forums: 
http://silex.hoyau.info/forum_en/

This release contains 4 folders:
- includes
- services
- swf
- conf

Once you have silex installed on your server, you need to 
- copy the contents of the includes folder to the cgi/includes/ folder of silex 
- copy the contents of the services folder to the cgi/services/ folder of silex 
- copy the contents of the swf folder to the media/components/oof folder of silex 
- copy the contents of the conf folder to the conf/ folder of silex 

Now to get started. The first step is probably the gallery tutorial:
http://silex-ria.org/media/tutoriel/Tutorial_how_to_make_a_gallery_in_Silex_with.pdf

We have lots more fun stuff in preparation. You can use OOF for many things, including using RSS, a database, contact forms, emails, etc.

 - If you want to use OOF with a database:
rename oof_db_config_sample.php to oof_db_config.php and reedit it to match your database configuration

- if you want to use OOF to send emails:
edit OofMail.ini

- Finally there is OofSecurity.ini. This is for protecting your database. You should be ok to start with it is as it is. 

A word of warning:
Oof is young, especially on the server side, so please don't use it yet to handle critical data. A guestbook should be fine, handling credit card numbers is not.

Thanks for trying OOF, 
the OOF team

