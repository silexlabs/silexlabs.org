<?php
/*
	this file is part of OOF
	OOF : Open Source Open Minded Flash Components

	OOF is (c) 2008 Alexandre Hoyau and Ariel Sommeria-Klein. It is released under the GPL License:

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License (GPL)
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/

/**
* this is a class for managing user accounts, designed so that it can be easily exposed through a webservice
* compatible with the API defined for the user_content_service.
* it also supports login/out, password regeneration, account confirmation.
* an email is sent for account confirmation at creation. 
* the confirmation itself and password regeneration, must be exposed elsewhere as they do not fit the API
*/
require_once("logger.php");
require_once("crud.php");
require_once(AMFPHP_BASE . "util/MethodTable.php");
require_once(AMFPHP_BASE . "util/Authenticate.php");

define(TABLE_USER,"User");


DEFINE(COLUMN_ID, "id");
DEFINE(COLUMN_NAME, "name");
DEFINE(COLUMN_PASSWORD, "password");
DEFINE(COLUMN_EMAIL, "email");
DEFINE(COLUMN_ROLE, "role");
DEFINE(COLUMN_CONFIRMATION_CODE, "confirmationCode");
DEFINE(COLUMN_ACTIVATED, "activated");
DEFINE(COLUMN_REST, "rest");

DEFINE(ID_USER, "idUser");

class account_manager{
	var $logger = null;
	var $crud = null;
	function account_manager(){
        $this->crud = new crud("account_manager");
		$this->logger = new logger("account_manager");
    }
    
 
   /**
    * login
    * @roles loggedUser,admin
    */
    function login(){
		return $this->readAccount();
	}
    /**
    * logout
    * @roles loggedUser,admin
    */
	function logout(){
	    Authenticate::logout();
        //idUser and role are custom and not included in basic logout method. so done afterwards
		if(isset($_SESSION[ID_USER]))
		{
			unset($_SESSION[ID_USER]);
		}
	    return true;
	}	
    
	function _authenticate($name, $password){
         $this->logger->debug("_authenticate, name : ".$name.", password : ".$password); 
		try{
                        
            $row = $this->getUserByName($name);
            $idUser = $row["id"];
			$role = $row["role"];
			
            if(sha1($password) != $row["password"]){
                 //wrong login
                throw new Exception("wrong password");
                break;
            }
            
			//this would be nice, but it means that silex must also play nice with oof. So don't change for now
/*			if(isset($_SESSION['amfphp_roles'])){
				$role = $role . ", " . $_SESSION['amfphp_roles'];
			}
*/			
			$this->logger->debug("role : " . $role . ", session : ".print_r($_SESSION, true));							

            //login ok, set session info and return role
            $_SESSION[ID_USER] = $idUser;
            return $role;            
        }catch(Exception $e){
            $this->logger->err("_authenticate error. ".$e->getMessage());
            $this->logger->debug("session : ".print_r($_SESSION, true));
            throw new Exception("_authenticate error");
        }
    }
	
	///private
	function getUserByName($name){
		$query = "SELECT * FROM " . TABLE_USER . " WHERE " . COLUMN_NAME . " = '" . $name . "'";
		$fromDb = $this->crud->connection->oofSqlQuery($query);
		$numRows = mysql_num_rows($fromDb);
		if($numRows == 0){
			return null;
		}else{
			return mysql_fetch_assoc($fromDb);
		}
	}
	
	///private
	function getUserByEmail($email){
		$query = "SELECT * FROM " . TABLE_USER . " WHERE " . COLUMN_EMAIL . " = '" . $email . "'";
		$fromDb = $this->crud->connection->oofSqlQuery($query);
		$numRows = mysql_num_rows($fromDb);
		if($numRows == 0){
			return null;
		}else{
			return mysql_fetch_assoc($fromDb);
		}
	}

	//private
	// see http://www.linuxjournal.com/article/9585 
	function validateEmailAddress($input){
	  $atom = '[a-zA-Z0-9!#$%&\'*+\-\/=?^_`{|}~]+';
	  $quoted_string = '"([\x1-\x9\xB\xC\xE-\x21\x23-\x5B\x5D-\x7F]|\x5C[\x1-\x9\xB\xC\xE-\x7F])*"';
	  $word = "$atom(\.$atom)*";
	  $domain = "$atom(\.$atom)+";
	  return strlen($input) < 256 && preg_match("/^($word|$quoted_string)@${domain}\$/", $input);
	}
	
	function commonCheckAndFormatItem($item){
		if(isset($item[COLUMN_ROLE])){
			throw new Exception("onRoleForbidden");
		}
		if(isset($item[COLUMN_ACTIVATED])){
			throw new Exception("onActivatedForbidden");
		}
		
		if(isset($item[COLUMN_CONFIRMATION_CODE])){
			throw new Exception("onConfirmationCodeForbidden");
		}
		
		if(isset($item[COLUMN_NAME])){
			//check availability of username
			$name = $item[COLUMN_NAME];
			if(strlen($name) < 6){
				throw new Exception("onNameTooShort");
			}

			if(strlen($name) > 20){
				throw new Exception("onNameTooLong");
			}

			if(!ctype_alnum($name)){
				throw new Exception("onNameNotAlphanumeric");
			}

			$row = $this->getUserByName($name);
			if($row && ($_SESSION[ID_USER] != $row[COLUMN_ID])){ 
				//if row and the name isn't the same as the one already existing(2nd condition useful for update)
				throw new Exception("onNameTaken");
			}
		}
		

		if(isset($item[COLUMN_PASSWORD])){
			$password = $item[COLUMN_PASSWORD];
			if(strlen($password) < 6){
				throw new Exception("onPasswordTooShort");
			}

			if(strlen($password) > 20){
				throw new Exception("onPasswordTooLong");
			}

			if(!ctype_alnum($password)){
				throw new Exception("onPasswordNotAlphanumeric");
			}

			$item[COLUMN_PASSWORD] = sha1($password);
		}

		if(isset($item[COLUMN_EMAIL])){
			$email = $item[COLUMN_EMAIL];
			if(!$this->validateEmailAddress($email)){
				throw new Exception("onInvalidEmail");
			}
			$row = $this->getUserByEmail($email);
			if($row && ($_SESSION[ID_USER] != $row[COLUMN_ID])){ 
				//if row and the name isn't the same as the one already existing(2nd condition useful for update)
				throw new Exception("onEmailTaken");
			}
		}
		
		//serialize unknown data into one "rest" item
		$ret = array();
		foreach($item as $key => $value){
			if(($key != COLUMN_NAME) && ($key != COLUMN_PASSWORD) && ($key != COLUMN_EMAIL)){
				$rest[$key] = $value;
				unset($item[$key]);
			}
		}
		
		$item[COLUMN_REST] = serialize($rest);
		return $item;
		
	
	}
    
	//item is an associative array with whatever you want to put in the user table. 
	//generates an error if you try to set the 'activated' or 'role' columns
    function createAccount($item){
        try{
			if(!isset($item[COLUMN_NAME])){
				throw new Exception("onNameMissing");
			}
			if(!isset($item[COLUMN_PASSWORD])){
				throw new Exception("onPasswordMissing");
			}
			if(!isset($item[COLUMN_EMAIL])){
				throw new Exception("onEmailMissing");
			}
			$item = $this->commonCheckAndFormatItem($item);
			$ret = $this->crud->createRecord(TABLE_USER, $item);            
			//$this->sendAccountConfirmationEmail($email);
			return $ret;
            
        }catch(Exception $e){
            $this->logger->err("createAccount error. ".$e->getMessage());
            $this->logger->debug("session : ".print_r($_SESSION, true));
            $this->logger->debug("item : ".print_r($item, true));
            throw new Exception($e->getMessage());
       }        
    }
    
	//item is an associative array with whatever you want to put in the user table. 
	//generates an error if you try to set the 'activated' or 'role' columns
    function updateAccount($item){
        try{
			$id = $_SESSION[ID_USER];
			if(!$id){
				throw new Exception("user not logged in");
			}
			$item = $this->commonCheckAndFormatItem($item);
            return $this->crud->updateRecord(TABLE_USER, $item, $id);            
                
        }catch(Exception $e){
            $this->logger->err("updateAccount error. ".$e->getMessage());
            $this->logger->debug("item : ".print_r($item, true));
            $this->logger->debug("session : ".print_r($_SESSION, true));
            throw new Exception($e->getMessage());
		}       
    }
	
	function readAccount(){
        try{
			$id = $_SESSION[ID_USER];
			if(!$id){
				throw new Exception("user not logged in");
			}
			
			$read = $this->crud->getIndividualRecords(TABLE_USER, array($id)); 
			//getIndividualRecords returns an array of records. single out the one we need
            $read = $read[0];
			//remove password, role,confirmationCode,  and activated from returned data
			unset($read[COLUMN_PASSWORD]);
			unset($read[COLUMN_ROLE]);
			unset($read[COLUMN_ACTIVATED]);
			unset($read[COLUMN_CONFIRMATION_CODE]);
			
			//unserialize rest
			$rest = unserialize($read[COLUMN_REST]);
			if($rest){
				foreach($rest as $key => $value){
					$read[$key] = $value;
				}
			}
			unset($read[COLUMN_REST]);
			
			return $read;
                
        }catch(Exception $e){
            $this->logger->err("readAccount error. ".$e->getMessage());
            $this->logger->debug("session : ".print_r($_SESSION, true));
            throw new Exception("readAccount error. " . $e->getMessage());
		}
	}    
	
	//private
    function sendAccountConfirmationEmail($email){
	//TODO
		$filename = CONFIRMATION_MAIL_TEMPLATE_PATH;
		$handle = fopen($filename, "r");
		$contents = fread($handle, filesize($filename));
		fclose($handle);
		$mailText = str_replace(PSEUDO_REPLACE, $pseudo, $contents);
		mail($email, "inscription Mastermots", $mailText);
		$this->logger->debug("sent mail : ".$mailText);
	}
	
	function regeneratePassword(){
		//TODO
	}
	
	function confirmAccount(){
	//TODO
	}
}
?>