<?php
/*
	this file is part of OOF
	OOF : Open Source Open Minded Flash Components

	OOF is (c) 2008 Alexandre Hoyau and Ariel Sommeria-Klein. It is released under the GPL License:

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License (GPL)
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/



//require_once(AMFPHP_BASE . "util/MethodTable.php");
require_once(AMFPHP_BASE . "../includes/email_manager.php");

class email_web_service{

  function email_web_service(){
        //$this->methodTable = MethodTable::create(__FILE__);
        require_once("email_web_service.methodTable.php");
    }
    
    /**
    * sendMail
    * @@access remote
    * @param subject(String)
    * @param body(String)
    * @param fromKey(String)
    * @param toKeys(String)
    * @param ccKeys(String)
    * @param bccKeys(String)
    * @returns Boolean
    */
    function sendMail($subject, $body, $fromKey, $toKeys, $ccKeys, $bccKeys){
		$emailManager = new email_manager();
		$emailManager->sendMail($subject, $body, $fromKey, $toKeys, $ccKeys, $bccKeys);
    }
    
    
}
?>