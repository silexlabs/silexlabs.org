<?php
/*
	this file is part of OOF
	OOF : Open Source Open Minded Flash Components

	OOF is (c) 2008 Alexandre Hoyau and Ariel Sommeria-Klein. It is released under the GPL License:

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License (GPL)
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/


require_once("../includes/user_content_manager.php");
//include(AMFPHP_BASE . "util/MethodTable.php");
 
 class form_web_service{
 
    function form_web_service(){
        //$this->methodTable = MethodTable::create(__FILE__);
        
        require_once("form_web_service.methodTable.php");
    }
    
    /**
    * getIndividualRecords
    * @access remote
    * @param form(String). name of the form from which to read the record
    * @param $ids(Array)
    */
    
    function getIndividualRecords($form, $ids){
		$userContentManager = new user_content_manager();
		return $userContentManager->getIndividualRecords($form, $ids);    
	}
    
     /**
    * createRecord
    * @access remote
    * @param form(String) form. name of the form from which to read the record
     * @param item(Array) for example {address: 'web site address', title:'boss'}
    */
    function createRecord($form, $item){
		$userContentManager = new user_content_manager();
		return $userContentManager->createRecord($form, $item);    
    }
    
     /**
    * updateRecord
    * @access remote
    * @param form(String) form. name of the form from which to read the record
    * @param item(Array)  for example {address: 'web site address', title:'boss'}
    * @param id(Integer)
    */
    function updateRecord($form, $item, $id){
		$userContentManager = new user_content_manager();
		return $userContentManager->updateRecord($form, $item, $id);    
    }
    
     /**
    * deleteRecord
    * @access remote
    * @param form(String) form. name of the form from which to read the record
    * @param id(Integer)
    */
    function deleteRecord($form, $id){
		$userContentManager = new user_content_manager();
		return $userContentManager->deleteRecord($form, $id);    
    }
    
    /**getRecords
    * @access remote
    * @param form(String)
    * @param fields(Array)
    * @param whereClause(String)
    * @param orderBy(String)
    * @param count(Number)
    * @param offset(Number)
    * @returns Array
    */
    function getRecords($form, $fields, $whereClause, $orderBy, $count, $offset){
		$userContentManager = new user_content_manager();
		return $userContentManager->getRecords($form, $fields, $whereClause, $orderBy, $count, $offset);    
  
    }

    

}


?>