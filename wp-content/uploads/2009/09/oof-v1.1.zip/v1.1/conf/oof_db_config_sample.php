<?php
	// ** MySQL settings - You can get this info from your web host ** //
	/** The name of the database for OOF */
	define('DB_NAME', 'Oof');

	/** MySQL database username */
	define('DB_USER', 'root');

	/** MySQL database password */
	define('DB_PASSWORD', '');

	/** MySQL hostname */
	define('DB_HOST', 'localhost');

	
?>