Silex Manager language file 

Place the file in the media/manager/language/ folder. Then open Silex manager and the language will be available.