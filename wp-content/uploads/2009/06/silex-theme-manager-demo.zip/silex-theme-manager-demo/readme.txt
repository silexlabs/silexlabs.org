------------------------------------------------------------------------
this file is part of SILEX
SILEX : RIA developement tool - see http://silex-ria.org/

SILEX is (c) 2004-2007 Alexandre Hoyau and is released under the GPL License:

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License (GPL)
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

To read the license please visit http://www.gnu.org/copyleft/gpl.html
------------------------------------------------------------------------


To use this theme,
- download Silex from here http://silex-ria.org/open.source.flash.cms/silex/telecharger
- install Silex - get help from here: http://silex-ria.org/#help/documentation/installation/install.home 
- copy the folder contents/cv into your Silex "contents/" folder
- copy the folder media/* into your Silex "media/" folder
