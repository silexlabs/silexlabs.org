Silex UI language file 

Place the file in the lang/ folder. Then login into Silex and the display will be in the desired language - unless your browser is configured with this language.